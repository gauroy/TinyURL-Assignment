#!/bin/bash

set -e
cd ../MAS_SVN
chmod +x ./gradlew
./gradlew build

echo "build.name=MAS $version" > buildVersion.txt
echo "build.number=$GO_PIPELINE_COUNTER" >> buildVersion.txt
echo "build.date=$(date)" >> buildVersion.txt

mkdir -p builds
mkdir -p build/builds/conf
mkdir -p build/builds/data
mkdir -p build/builds/log
mkdir -p build/builds/DB/sql

cp  DB/sql/* build/builds/DB/sql/
cp -r build/builds/* builds/
zip -r builds.zip builds buildVersion.txt

mkdir -p ../release/templates
mkdir -p ../scripts/dist

cp ../MAS_SVN/builds.zip  ../scripts/dist/build.zip
cp ../MAS_SVN/CICD/master_template.j2 ../release/templates/master_template.j2
cp ../MAS_SVN/CICD/stack.json ../release/templates/stack.json
cp ../MAS_SVN/CICD/deploy.json ../release/templates/deploy.json
