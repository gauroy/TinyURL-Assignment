git clone https://manish_kumar01@bitbucket.org/procurement_zycus/isupplier.git

cd isupplier

git checkout release/Release-19.1.0.0

cd ..

git clone https://manish_kumar01@bitbucket.org/procurement_zycus/integrity-audittrail-commons.git

cd integrity-audittrail-commons

git checkout develop

cd ..

git clone https://manish_kumar01@bitbucket.org/procurement_zycus/integrity-audittrail.git

cd integrity-audittrail

git checkout develop

cd ..

git clone https://manish_kumar01@bitbucket.org/procurement_zycus/integritycommons.git

cd integritycommons

git checkout develop

cd ..

git clone https://manish_kumar01@bitbucket.org/procurement_zycus/integritycommons-model.git

cd integritycommons-model

git checkout develop

cd ..

git clone https://manish_kumar01@bitbucket.org/procurement_zycus/viewmanager-commons.git

cd viewmanager-commons

git checkout develop

cd ..
 
git clone https://manish_kumar01@bitbucket.org/procurement_zycus/viewmanager.git

cd viewmanager

git checkout develop

cd ..

git clone https://manish_kumar01@bitbucket.org/procurement_zycus/consulhelper.git

cd consulhelper

git checkout develop

cd ..

git clone https://manish_kumar01@bitbucket.org/procurement_zycus/healthcheck-commons.git

cd healthcheck-commons

git checkout develop

cd ..