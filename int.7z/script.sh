#!/bin/bash
export PATH=/home/go/maven-3.5.0/bin:$PATH
mvn -s /usr/share/maven/conf/settings.xml -U -f ../sim-redis-repository/pom.xml clean install -DskipTests
echo "build.name=sim-redis-repository $version" >> buildVersion.txt
echo "build.number=$GO_PIPELINE_COUNTER" >> buildVersion.txt
echo "build.date=$(date +%Y-%m-%d\ %H:%M:%S\ %Z)" >> buildVersion.txt 
chmod 775 -R *
mkdir -p build/sim-redis-repository
mv ../sim-redis-repository/CICD/template/ build/sim-redis-repository
mv ../sim-redis-repository/target/*.jar build/sim-redis-repository
zip -r builds.zip build/sim-redis-repository buildVersion.txt
