package com.zycus.sim.redisrepository.controller;

import app.zycus.bp.simapi.bo.ContactDetails;
import com.google.common.collect.Lists;
import com.zycus.sim.api.errors.NoResourceFoundException;
import com.zycus.sim.api.errors.RequiredParametersMissing;
import com.zycus.sim.redisrepository.model.CachedSupplier;
import com.zycus.sim.redisrepository.service.RedisCacheReadServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/cache/supplier")
public class ContactsController {
    private static final Logger logger= LoggerFactory.getLogger(ContactsController.class);

    @Autowired
    RedisCacheReadServiceImpl redisReadCacheService;

    @RequestMapping(value = "/contacts", method = RequestMethod.GET)
    public @ResponseBody List<ContactDetails> findContactsByEmailAndDBA(@RequestHeader("tenant_id") String tmsTenantId,
                                                          @RequestParam("e") String email,
                                                          @RequestParam("d") List<String> dbaIds ) {

        if (tmsTenantId == null || tmsTenantId.trim().isEmpty()) {
            logger.error("tmsTenantId is null or empty");
            throw new RequiredParametersMissing("Invalid or Missing TMS Tenant ID");
        }
        if (email == null || email.trim().isEmpty()) {

            logger.error("Email Id is null or empty");
            throw new RequiredParametersMissing("Invalid or Missing Email ID");
        }
        if (dbaIds == null || dbaIds.isEmpty()) {

            logger.error("DBA Id is null or empty");
            throw new RequiredParametersMissing("Invalid or Missing DBA IDs");
        }

        Iterable<ContactDetails> retVal = redisReadCacheService.findAllContactsByDBAIdsAndEmail(tmsTenantId, email, dbaIds);

        if (retVal == null ) {
            throw new NoResourceFoundException(
                    String.format("No Contacts Cached for DBA ids [%s] and Email [%s] for tenant %s", String.join(",",dbaIds),email, tmsTenantId));
        }

        List<ContactDetails> contacts = Lists.newArrayList(retVal);
        if(contacts ==null || contacts.isEmpty()) {
            throw new NoResourceFoundException(
                    String.format("No Contacts Cached for DBA ids [%s] and Email [%s] for tenant %s", String.join(",",dbaIds),email, tmsTenantId));
        }
        return contacts;
    }
}
