package com.zycus.sim.redisrepository.jmslisteners;

import com.zycus.sim.redisrepository.RedisRepositoryApplication;
import com.zycus.sim.redisrepository.service.RedisCacheWriteServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.jms.Message;
import javax.jms.ObjectMessage;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

@Component
public class SupplierChangeListener implements Function<Message, Boolean> {
    private static final Logger logger = LoggerFactory.getLogger(SupplierChangeListener.class);

    @Value("${enable-ids:true}")
    private Boolean isIdsEnabled;

    private RedisCacheWriteServiceImpl service;

    SupplierChangeListener() {
    }

    public SupplierChangeListener(RedisCacheWriteServiceImpl service) {
        this.service = service;

    }

    public Boolean apply(Message event) {

        if (!isIdsEnabled) {
            try {
                logger.info("IDS is NOT enabled or either the queue is still subscribed(remove the subscription from activeMQ, so listening to queue {} with event-message-id: {}",
                        RedisRepositoryApplication.TOPIC_SIM_SUPPLIER, event.getJMSMessageID());
                if (service.lock(event.getJMSMessageID())) {
                    Map<String, Object> map = (Map<String, Object>) ((ObjectMessage) event).getObject();
                    service.loadSuppliersForTenantInRedis(map.get("TMS_CLIENTID").toString(), (List<String>) map.get("LIST_OF_SUPPLIERID"));
                    service.unlock(event.getJMSMessageID());
                }
            } catch (Throwable e) {
                logger.error("Failed to update Redis", e);
                return false;
            }
        }
        return true;
    }

}
