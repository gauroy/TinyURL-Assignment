package com.zycus.sim.redisrepository.model;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@RedisHash("externalSuppliers")
public class ExtSupplier implements Serializable {

	@Id
	private String id;
	private String zycusSupplierId;
	
	
	public ExtSupplier() {
		
	}
	
	public ExtSupplier(String extSupplierId, String supplierId) {
		id = extSupplierId;
		this.zycusSupplierId = supplierId;
	}

}
