package com.zycus.sim.redisrepository.service;

import com.zycus.sim.redisrepository.model.CachedSupplier;

import java.util.List;

public interface ISupplierService
{
	public List<CachedSupplier> findSupplierBySupplierIdFromSIM(String tmsTenantId, List<String> supplierIds);

	public CachedSupplier findSuppliersByERPIdsFromSIM(String tmsTenantId, String erpIds);

	public CachedSupplier findSupplierByDBAIdFromSIM(String tmsTenantId, String dbaIds);

}
