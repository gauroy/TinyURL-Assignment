package com.zycus.sim.redisrepository.model;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@RedisHash("dbas")
public class CachedDBA implements Serializable {
	@Id
	private String id;
	
	private String name;
	
	private String zycusSupplierId;
	
	public CachedDBA() {}
	
	
	
	public CachedDBA(String dbaId, String supplierId, String name) {
		id = dbaId;
		this.zycusSupplierId = supplierId;
		this.name =  name;
	}
}
