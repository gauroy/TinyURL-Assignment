package com.zycus.sim.redisrepository.model;

import org.springframework.data.annotation.Id;

public class SIMClient {
	
		@Id
		private String	tmsClientID	;
		
		private String	internalClientID;
	
		public SIMClient() {}
		
		public SIMClient(String tmsClientID, String internalClientID) {
			this.tmsClientID = tmsClientID;
			this.internalClientID = internalClientID;
		}
	
		public String getTmsClientID() {
			return tmsClientID;
		}
	
		public void setTmsClientID(String tmsClientID) {
			this.tmsClientID = tmsClientID;
		}
	
		public String getInternalClientID() {
			return internalClientID;
		}
	
		public void setInternalClientID(String internalClientID) {
			this.internalClientID = internalClientID;
		}

	
	
}
