package com.zycus.sim.redisrepository.configurations;

import io.lettuce.core.ClientOptions;
import io.lettuce.core.ReadFrom;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisSentinelConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

import java.time.Duration;
import java.util.Arrays;

@Configuration
@EnableConfigurationProperties(RedisProperties.class)
public class RedisConfig
{
	private static final Logger logger = LoggerFactory.getLogger(RedisConfig.class);

	/*@Value("${sim.redis.cache.ttl:100}")
	public long cacheKeyTTL = 100;*/

	@Value("${sim.redis.sentinel.master-name:master01}")
	public String sentinelMaster;

	@Value("${sim.redis.sentinel.db-no: 0}")
	public int redisDbNo = 0;

	@Value("${sim.redis.pool.command-timeout:5}")
	public int commandTimeout = 5;

	@Value("${sim.redis.pool.max-idle:50}")
	public int maxIdle = 50;

	@Value("${sim.redis.pool.min-idle:10}")
	public int minIdle = 10;

	@Value("${sim.redis.pool.max-total:200}")
	public int maxTotal = 200;

	@Value("${sim.redis.pool.max-wait-millis:12000}")
	public int maxWaitMillis = 12000;

	@Value("${sim.redis.pool.num-test-per-eviction:10}")
	public int numTestsPerEvictionRun = 10;

	@Value("${sim.redis.sentinel-nodes}")
	public String sentinelIPs;

	@Bean
	public RedisTemplate<Object, Object> redisTemplate(RedisConnectionFactory redisConnectionFactory)
	{
		RedisTemplate<Object, Object> redisTemplate = new RedisTemplate<>();
		redisTemplate.setConnectionFactory(lettuceConnectionFactory());
		return redisTemplate;
	}

	private LettuceConnectionFactory lettuceConnectionFactory()
	{

		logger.info("Initializing lettuceConnectfactory...");

		RedisSentinelConfiguration redisSentinalConfiguration = new RedisSentinelConfiguration();

		redisSentinalConfiguration.master(sentinelMaster);

		String[] sentinalIPs = sentinelIPs.split(";");
		Arrays.stream(sentinalIPs).forEach(value -> {
			String sentinalIP[] = value.split(":");
			redisSentinalConfiguration.sentinel(sentinalIP[0], Integer.valueOf(sentinalIP[1]));
		});

		redisSentinalConfiguration.setDatabase(redisDbNo);

		LettuceClientConfiguration clientConfig = LettuceClientConfiguration.builder()
				.readFrom(ReadFrom.SLAVE_PREFERRED).clientOptions(
						ClientOptions.builder().autoReconnect(true).cancelCommandsOnReconnectFailure(true)
								.disconnectedBehavior(ClientOptions.DisconnectedBehavior.REJECT_COMMANDS)
								// .timeoutOptions(timeoutOptions)
								.build()).commandTimeout(Duration.ofSeconds(commandTimeout))
				//.commandTimeout(Duration.ofMillis(1))
				.build();

		GenericObjectPoolConfig poolConfig = new GenericObjectPoolConfig();
		poolConfig.setMaxIdle(maxIdle);
		poolConfig.setMinIdle(minIdle);
		poolConfig.setMaxTotal(maxTotal);
		poolConfig.setMaxWaitMillis(maxWaitMillis);
		poolConfig.setBlockWhenExhausted(false);
		poolConfig.setTestOnCreate(true);
		poolConfig.setTestOnBorrow(true);
		poolConfig.setTestOnReturn(false);
		poolConfig.setTestWhileIdle(false);
		poolConfig.setNumTestsPerEvictionRun(numTestsPerEvictionRun);

		CustomLettucePoolingClientConfiguration poolClienConfig = new CustomLettucePoolingClientConfiguration(
				clientConfig, poolConfig);

		LettuceConnectionFactory lettuceConnectionFactory = new LettuceConnectionFactory(redisSentinalConfiguration,
				poolClienConfig);

		//This is imp
		lettuceConnectionFactory.afterPropertiesSet();

		return lettuceConnectionFactory;
	}

}
