package com.zycus.sim.redisrepository.service;

import app.zycus.bp.simapi.bo.ContactDetails;
import app.zycus.bp.simapi.bo.SIMSupplierBo;
import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.zycus.sim.redisrepository.model.CachedDBA;
import com.zycus.sim.redisrepository.model.CachedSupplier;
import com.zycus.sim.redisrepository.model.ExtSupplier;
import com.zycus.sim.redisrepository.repository.CachedDBARepository;
import com.zycus.sim.redisrepository.repository.CachedSupplierRepository;
import com.zycus.sim.redisrepository.repository.ExtSupplierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class RedisCacheReadServiceImpl {
    @Autowired
    CachedSupplierRepository cachedSupplierRepo;
    @Autowired
    ExtSupplierRepository extSupplierRepo;
    @Autowired
    CachedDBARepository cachedDbaRepo;


    public Optional<CachedSupplier> findById(String tmsTenantId, String supplierId) {
        return cachedSupplierRepo.findById(tmsTenantId + "-" + supplierId);
    }

    public Optional<CachedSupplier> findByERPId(String tmsTenantId, String erpId) {
        Optional<ExtSupplier> ops = extSupplierRepo.findById(tmsTenantId + "-" + erpId);
        if (ops.isPresent()) {
            return cachedSupplierRepo.findById(ops.get().getZycusSupplierId());
        }
        return Optional.empty();
    }

    public Optional<CachedSupplier> findByDBAId(String tmsTenantId, String dbaId) {
        Optional<CachedDBA> ops = cachedDbaRepo.findById(tmsTenantId + "-" + dbaId);
        if (ops.isPresent()) {
            return cachedSupplierRepo.findById(ops.get().getZycusSupplierId());
        }
        return Optional.empty();
    }

    public Iterable<CachedSupplier> findAllBySupplierIds(String tmsTenantId, List<String> supplierIds) {
        Set<String> ids = supplierIds.stream().map(s -> tmsTenantId + "-" + s).collect(Collectors.toSet());
        return cachedSupplierRepo.findAllById(ids);
    }


    public Iterable<CachedSupplier> findAllByERPIds(String tmsTenantId, List<String> erpId) {
        Set<String> erpIdSet = erpId.stream().map(s -> tmsTenantId + "-" + s).collect(Collectors.toSet());

        if (erpIdSet != null && !erpIdSet.isEmpty()) {
            Iterable<ExtSupplier> suppliers = extSupplierRepo.findAllById(erpIdSet);
            if (suppliers != null) {
                return cachedSupplierRepo.findAllById(Lists.newArrayList(suppliers).stream().map(s -> s.getZycusSupplierId()).collect(Collectors.toSet()));
            }
        }
        return new ArrayList<>();

    }

    public Iterable<CachedSupplier> findAllByDBAIds(String tmsTenantId, List<String> dbaId) {
        Set<String> dbaIdSet = dbaId.stream().map(s -> tmsTenantId + "-" + s).collect(Collectors.toSet());
        if (dbaIdSet != null && !dbaIdSet.isEmpty()) {
            Iterable<CachedDBA> suppliers = cachedDbaRepo.findAllById(dbaIdSet);
            if (suppliers != null) {
                return cachedSupplierRepo.findAllById(Lists.newArrayList(suppliers).stream().map(s -> s.getZycusSupplierId()).collect(Collectors.toSet()));
            }
        }
        return new ArrayList<>();
    }


    public Iterable<ContactDetails> findAllContactsByDBAIdsAndEmail(String tmsTenantId, String email, List<String> dbaId) {

        Iterable<CachedSupplier> suppliers = findAllByDBAIds(tmsTenantId, dbaId);
        if (suppliers != null && suppliers.iterator().hasNext()) {
            Set<ContactDetails> contactDetails = Lists.newArrayList(suppliers).stream().distinct()
                    .filter(s -> s != null)
                    .map(s -> s.getData()).map(d -> new Gson().fromJson(d, SIMSupplierBo.class))
                    .filter(s -> s != null)
                    .filter(s -> s.getSupplierProfile() != null && s.getSupplierProfile().getSupContactDetailsList() != null && !s.getSupplierProfile().getSupContactDetailsList().isEmpty())
                    .flatMap(s -> s.getSupplierProfile().getSupContactDetailsList().stream())
                    .filter(c -> email.equals(c.getemail()))
                    .collect(Collectors.toSet());
            if (contactDetails != null && !contactDetails.isEmpty()) {
                return contactDetails;
            }
        }

        return new ArrayList<>();
    }


}
