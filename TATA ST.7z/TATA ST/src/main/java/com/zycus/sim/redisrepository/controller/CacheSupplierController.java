package com.zycus.sim.redisrepository.controller;

import com.google.common.collect.Iterables;
import com.google.common.collect.Lists;
import com.zycus.sim.api.errors.*;
import com.zycus.sim.redisrepository.model.CachedSupplier;
import com.zycus.sim.redisrepository.service.ISupplierService;
import com.zycus.sim.redisrepository.service.RedisCacheReadServiceImpl;
import com.zycus.sim.redisrepository.service.RedisCacheWriteServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/cache")
public class CacheSupplierController {

    private static final Logger logger = LoggerFactory.getLogger(CacheSupplierController.class);

    @Autowired
    RedisCacheWriteServiceImpl redisWriteCacheService;

    @Autowired
    RedisCacheReadServiceImpl redisReadCacheService;

    @Autowired
    ISupplierService supplierService;

    @RequestMapping(value = "/supplier/sim-redis", method = RequestMethod.POST)

    public @ResponseBody
    String cacheSuppliersInRedis(
            @RequestHeader("tenant_id")
                    String tmsTenantId,
            @RequestParam(value = "ids", required = false)
                    List<String> supplierIds,
            @RequestParam(value = "start_index", required = false, defaultValue = "1")
                    int startIndex) {

        if (tmsTenantId == null || tmsTenantId.trim().isEmpty()) {

            logger.error("tmsTenantId is null or empty");
            throw new RequiredParametersMissing("Invalid or Missing Tenant ID");
        }
        long processedSuppliers = 0L;
        try {
            if (supplierIds == null || supplierIds.isEmpty()) {
                processedSuppliers = redisWriteCacheService.loadAllSuppliersForTenantInRedis(tmsTenantId, startIndex);
            } else {
                processedSuppliers = redisWriteCacheService.loadSuppliersForTenantInRedis(tmsTenantId, supplierIds);
            }
        } catch (ApiException e) {
            logger.error("Failed to Process!", e);
            throw e;
        } catch (Exception e) {
            logger.error("Failed to Process!", e);
            throw new DataFetchException("Failed to Process!", e);
        }

        if (processedSuppliers == 0) {
            throw new NoResourceFoundException("No Suppliers found for query, nothing loaded!");
        }
        return String.format("Successfully Loaded %d Suppliers", processedSuppliers);
    }

    @RequestMapping(value = "/supplier/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String findSupplierBySupplierId(
            @RequestHeader("tenant_id")
                    String tmsTenantId,
            @PathVariable("id")
                    String supplierId) {

        if (tmsTenantId == null || tmsTenantId.trim().isEmpty()) {

            logger.error("tmsTenantId is null or empty");
            throw new RequiredParametersMissing("Invalid or Missing TMS Tenant ID");
        }
        if (supplierId == null || supplierId.trim().isEmpty()) {

            logger.error("supplierId is null or empty");
            throw new RequiredParametersMissing("Invalid or Missing Supplier ID");
        }
        Optional<CachedSupplier> retVal = redisReadCacheService.findById(tmsTenantId, supplierId);

        if (retVal.isPresent()) {
            return retVal.get().getData();
        } else {
            logger.error("No Supplier Cached in Redis for id %s for tenant %s, fetching suppliers from SIM DB",
                    supplierId, tmsTenantId);
            List<CachedSupplier> cachedSuppliers = null;
            try {
                cachedSuppliers = supplierService
                        .findSupplierBySupplierIdFromSIM(tmsTenantId, Arrays.asList(supplierId));
            } catch (Exception e) {
                logger.error("Issue occured while fetching data from SIM DB for tenantId: {}, supplierId: {}", tmsTenantId, supplierId, e);
                throw new NoResourceFoundException(String.format("Issue occured while fetching data from SIM DB for id %s for tenant %s", supplierId, tmsTenantId));
            }

            if (cachedSuppliers != null && !cachedSuppliers.isEmpty()) {
                return cachedSuppliers.get(0).getData();
            } else {
                throw new NoResourceFoundException(
                        String.format("No Supplier Found in Redis and also in DB for id %s for tenant %s", supplierId,
                                tmsTenantId));
            }
        }
    }

    @RequestMapping(value = "/suppliers", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String findSuppliersByIds(
            @RequestHeader("tenant_id")
                    String tmsTenantId,
            @RequestParam("ids")
                    List<String> supplierIds) {

        if (tmsTenantId == null || tmsTenantId.trim().isEmpty()) {

            logger.error("tmsTenantId is null or empty");
            throw new RequiredParametersMissing("Invalid or Missing TMS Tenant ID");
        }
        if (supplierIds == null || supplierIds.isEmpty()) {

            logger.error("supplierId is null or empty");
            throw new RequiredParametersMissing("Invalid or Missing Supplier IDs");
        }
        if (supplierIds.size() > 10) {
            throw new InvalidParameterException("Maximum of 10 ids can be returned in one group");
        }
        Iterable<CachedSupplier> retVal = redisReadCacheService.findAllBySupplierIds(tmsTenantId, supplierIds);

        if (retVal != null && Iterables.size(retVal) > 0) {
            List<CachedSupplier> suppliers = Lists.newArrayList(retVal);
            return "[" + String.join(",", suppliers.stream().map(c -> c.getData()).collect(Collectors.toList())) + "]";
        } else {
            logger.error("No Supplier Cached in Redis for ids [%s] for tenant %s, fetching suppliers from SIM DB",
                    String.join(",", supplierIds), tmsTenantId);
            List<CachedSupplier> dbSuppliers = null;

            try {
                dbSuppliers = supplierService.findSupplierBySupplierIdFromSIM(tmsTenantId, supplierIds);
            } catch (Exception e) {
                logger.error("Issue occured while fetching data from SIM DB for tenantId: {}, supplierId: {}", tmsTenantId, Arrays.toString(supplierIds.toArray()), e);
                throw new NoResourceFoundException(String.format("Issue occured while fetching data from SIM DB for id %s for tenant %s", supplierIds, tmsTenantId));
            }

            if (dbSuppliers != null && !dbSuppliers.isEmpty()) {
                return "[" + String.join(",", dbSuppliers.stream().map(c -> c.getData()).collect(Collectors.toList()))
                        + "]";
            } else {
                throw new NoResourceFoundException(
                        String.format("No Supplier Found in Redis and also in DB for id %s for tenant %s", supplierIds,
                                tmsTenantId));
            }
        }
    }

    /* To Load Suppliers based on multiple ERP ID
     *
     * */
    @RequestMapping(value = "/suppliers/erp", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String findSuppliersByERPIds(
            @RequestHeader("tenant_id")
                    String tmsTenantId,
            @RequestParam("ids")
                    List<String> erpId) {

        if (tmsTenantId == null || tmsTenantId.trim().isEmpty()) {
            throw new RequiredParametersMissing("Invalid or Missing TMS Tenant ID");
        }
        if (erpId == null || erpId.isEmpty()) {
            throw new RequiredParametersMissing("Invalid or Missing External ERP IDs");
        }

        if (erpId.size() > 10) {
            throw new InvalidParameterException("Maximum of 10 ids can be returned in one group");
        }

        Iterable<CachedSupplier> retVal = redisReadCacheService.findAllByERPIds(tmsTenantId, erpId);

        if (retVal == null) {
            throw new NoResourceFoundException(
                    String.format("No Supplier Cached for ids [%s] for tenant %s", String.join(",", erpId),
                            tmsTenantId));
        }

        List<CachedSupplier> suppliers = Lists.newArrayList(retVal);
        if (suppliers == null || suppliers.isEmpty()) {
            throw new NoResourceFoundException(
                    String.format("No Supplier Cached for ids [%s] for tenant %s", String.join(",", erpId),
                            tmsTenantId));
        }
        return "[" + String.join(",", suppliers.stream().map(c -> c.getData()).collect(Collectors.toList())) + "]";

    }

    /* To Load Supplier Based on single ERP ID
     *
     * */

    @RequestMapping(value = "/supplier/erp/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String findSupplierByERPIds(
            @RequestHeader("tenant_id")
                    String tmsTenantId,
            @PathVariable("id")
                    String erpId) {

        if (tmsTenantId == null || tmsTenantId.trim().isEmpty()) {
            throw new RequiredParametersMissing("Invalid or Missing TMS Tenant ID");
        }
        if (erpId == null || erpId.trim().isEmpty()) {
            throw new RequiredParametersMissing("Invalid or Missing External ERP ID");
        }

        Optional<CachedSupplier> retVal = redisReadCacheService.findByERPId(tmsTenantId, erpId);
        if (!retVal.isPresent()) {
            throw new NoResourceFoundException(
                    String.format("No Supplier Cached for id %s for tenant %s", erpId, tmsTenantId));
        }
        return retVal.get().getData();

    }

    @RequestMapping(value = "/supplier/dba/{id}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String findSupplierByDBAId(
            @RequestHeader("tenant_id")
                    String tmsTenantId,
            @PathVariable("id")
                    String dbaId) {

        if (tmsTenantId == null || tmsTenantId.trim().isEmpty()) {
            throw new RequiredParametersMissing("Invalid or Missing TMS Tenant ID");
        }
        if (dbaId == null || dbaId.trim().isEmpty()) {
            throw new RequiredParametersMissing("Invalid or Missing External DBA ID");
        }

        Optional<CachedSupplier> retVal = redisReadCacheService.findByDBAId(tmsTenantId, dbaId);
        if (!retVal.isPresent()) {
            throw new NoResourceFoundException(
                    String.format("No Supplier Cached for id %s for tenant %s", dbaId, tmsTenantId));
        }
        return retVal.get().getData();

    }

    @RequestMapping(value = "/suppliers/dba", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String findSuppliersByDBAIds(
            @RequestHeader("tenant_id")
                    String tmsTenantId,
            @RequestParam("ids")
                    List<String> dbaId) {

        if (tmsTenantId == null || tmsTenantId.trim().isEmpty()) {
            throw new RequiredParametersMissing("Invalid or Missing TMS Tenant ID");
        }
        if (dbaId == null || dbaId.isEmpty()) {
            throw new RequiredParametersMissing("Invalid or Missing External DBA IDs");
        }

        if (dbaId.size() > 10) {
            throw new InvalidParameterException("Maximum of 10 ids can be returned in one group");
        }

        Iterable<CachedSupplier> retVal = redisReadCacheService.findAllByDBAIds(tmsTenantId, dbaId);
        if (retVal == null) {
            throw new NoResourceFoundException(
                    String.format("No Supplier Cached for ids [%s] for tenant %s", String.join(",", dbaId),
                            tmsTenantId));
        }

        List<CachedSupplier> suppliers = Lists.newArrayList(retVal);
        if (suppliers == null || suppliers.isEmpty()) {
            throw new NoResourceFoundException(
                    String.format("No Supplier Cached for ids [%s] for tenant %s", String.join(",", dbaId),
                            tmsTenantId));
        }
        return "[" + String.join(",", suppliers.stream().map(c -> c.getData()).collect(Collectors.toList())) + "]";

    }

    @RequestMapping(value = "supplier/solr", method = RequestMethod.PUT, produces = MediaType.APPLICATION_JSON_VALUE)
    public @ResponseBody
    String reloadSolr(
            @RequestHeader("tenant_id")
                    String tmsTenantId,
            @RequestParam(value = "ids", required = false)
                    List<String> supplierIds) {

        if (tmsTenantId == null || tmsTenantId.trim().isEmpty()) {

            logger.error("tmsTenantId is null or empty");
            throw new RequiredParametersMissing("Invalid or Missing Tenant ID");
        }
        long processedSuppliers = 0;
        try {
            if (supplierIds == null || supplierIds.isEmpty()) {
                processedSuppliers = redisWriteCacheService.syncAllSuppliersForTenantWithSolr(tmsTenantId);
            } else {
                processedSuppliers = redisWriteCacheService.syncSuppliersForTenantWithSolr(tmsTenantId, supplierIds);
            }
        } catch (ApiException e) {
            logger.error("Failed to Process!", e);
            throw e;
        } catch (Exception e) {
            logger.error("Failed to Process!", e);
            throw new DataFetchException("Failed to Process!", e);
        }

        if (processedSuppliers == 0) {
            throw new NoResourceFoundException("No Suppliers found for query, nothing loaded!");
        }
        return String.format("Successfully Loaded %d Suppliers", processedSuppliers);

    }

}
