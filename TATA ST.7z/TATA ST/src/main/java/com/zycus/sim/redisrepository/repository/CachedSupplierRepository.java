package com.zycus.sim.redisrepository.repository;


import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.QueryByExampleExecutor;
import org.springframework.stereotype.Repository;

import com.zycus.sim.redisrepository.model.CachedSupplier;

import java.util.List;


public interface CachedSupplierRepository extends CrudRepository<CachedSupplier, String>, QueryByExampleExecutor<CachedSupplier> {

    List<CachedSupplier> findByTmsClientId(String tmsClientId);
    Page<CachedSupplier> findCachedSupplierByTmsClientId(String tmsClientId, Pageable page);
}
