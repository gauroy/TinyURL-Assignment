package com.zycus.sim.redisrepository.service;

import app.zycus.bp.simapi.bo.ERPDetailsBO;
import app.zycus.bp.simapi.bo.SIMSupplierBo;
import com.google.gson.Gson;
import com.zycus.sim.api.errors.DependentServiceUnavailable;
import com.zycus.sim.common.event.model.AsyncEvent;
import com.zycus.sim.common.event.queue.QueueAdapter;
import com.zycus.sim.redisrepository.model.CachedDBA;
import com.zycus.sim.redisrepository.model.CachedSupplier;
import com.zycus.sim.redisrepository.model.ExtSupplier;
import com.zycus.sim.redisrepository.repository.CachedDBARepository;
import com.zycus.sim.redisrepository.repository.CachedSupplierRepository;
import com.zycus.sim.redisrepository.repository.ExtSupplierRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.*;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@Component
public class RedisCacheServiceHelper {
    @Autowired
    private CachedSupplierRepository cachedSupplierRepo;

    @Autowired
    private ExtSupplierRepository extSupplierRepo;

    @Autowired
    private CachedDBARepository cachedDBARepo;

    @Autowired
    private QueueAdapter adapter;

    @Value("${sim.solr.queue}")
    private String queueName;

    private static Logger logger = LoggerFactory.getLogger(RedisCacheServiceHelper.class);


    public void saveExtSuppliers(String tmsTenantId, List<SIMSupplierBo> supplierBoList) {
        extSupplierRepo.saveAll(supplierBoList.stream()
                .filter(bo -> bo.getSupplierProfile() != null && bo.getSupplierProfile().getCompanyDetails() != null
                        && bo.getSupplierProfile().getCompanyDetails().getErpDetailsList() != null)
                .flatMap(bo -> bo.getSupplierProfile().getCompanyDetails().getErpDetailsList().stream().map(erp -> new AbstractMap.SimpleEntry<Long, ERPDetailsBO>(bo.getZycusSupplierId(), erp)).collect(Collectors.toList()).stream())
                .filter(entry -> entry.getValue().getErpId() != null && !entry.getValue().getErpId().trim().isEmpty()).map(bo -> new ExtSupplier(tmsTenantId + "-" + bo.getValue().getErpId(), tmsTenantId + "-" + bo.getKey()))
                .collect(Collectors.toList()));
        logger.info(String.format("Loaded %d External Suppliers for %s", supplierBoList.size(), tmsTenantId));
    }


    public void saveSuppliers(String tmsTenantId, List<SIMSupplierBo> supplierBoList) {
        cachedSupplierRepo.saveAll(supplierBoList.stream()
                .map(supplierBo -> new CachedSupplier(tmsTenantId, supplierBo)).collect(Collectors.toList()));
        logger.info(String.format("Loaded %d Suppliers for %s", supplierBoList.size(), tmsTenantId));

    }


    public void saveDBAs(String tmsTenantId, List<SIMSupplierBo> supplierBoList) {
        cachedDBARepo.saveAll(supplierBoList.stream().flatMap(supplierBo -> {
            List<CachedDBA> dbaList = new ArrayList<>();
            dbaList.add(new CachedDBA(tmsTenantId + "-" + supplierBo.getDbaId(),
                    tmsTenantId + "-" + supplierBo.getZycusSupplierId(), supplierBo.getName()));
            dbaList.addAll(supplierBo.getSupplierProfile().getDbaAlias().stream()
                    .map(d -> new CachedDBA(tmsTenantId + "-" + d.getdbaid(),
                            tmsTenantId + "-" + supplierBo.getZycusSupplierId(), d.getname()))
                    .collect(Collectors.toList()));
            return dbaList.stream();
        }).collect(Collectors.toList()));
        logger.info(String.format("Loaded %d DBAs for %s", supplierBoList.size(), tmsTenantId));
    }


    public void postToJMSForSolrUpdate(String tmsTenantId, String msgId, String correlationId,
                                       List<SIMSupplierBo> supplierBoList) {
        try {
            adapter.raiseEvent(new AsyncEvent<>(tmsTenantId, msgId, correlationId, queueName, supplierBoList));
            logger.info(String.format("Raised Event for %d suppliers for %s, msg: %s, correlationId: %s on queue %s", supplierBoList.size(), tmsTenantId, msgId, correlationId, queueName));
        } catch (Exception e) {
            logger.error(String.format("Failed to raise Event for %d suppliers for %s, msg: %s, correlationId: %s on queue %s", supplierBoList.size(), tmsTenantId, msgId, correlationId, queueName), e);
            throw new DependentServiceUnavailable("Unable to raise Event in JMS for Updating Solr", e);
        }
    }

    public List<SIMSupplierBo> getSuppliersForTenant(String tmsTenantId) {
//        CachedSupplier cs = new CachedSupplier();
//        cs.setTmsClientId(tmsTenantId);
        //Iterable<CachedSupplier> ics = cachedSupplierRepo.findAllById(template.keys(tmsTenantId+"-*"));
        List<CachedSupplier> lst = cachedSupplierRepo.findByTmsClientId(tmsTenantId);
        //return StreamSupport.stream(ics.spliterator(), false).filter(sup->tmsTenantId.equals(sup.getTmsClientId())).map(sup -> sup.getData()).map(s -> new Gson().fromJson(s, SIMSupplierBo.class)).collect(Collectors.toList());
        return lst.stream().filter(sup->tmsTenantId.equals(sup.getTmsClientId())).map(sup -> sup.getData()).map(s -> new Gson().fromJson(s, SIMSupplierBo.class)).collect(Collectors.toList());
    }

    public Page<SIMSupplierBo> getSuppliersForTenant(String tmsTenantId, PageRequest pageRequest) {
        return cachedSupplierRepo.findCachedSupplierByTmsClientId(tmsTenantId, pageRequest ).map(sup -> new Gson().fromJson(sup.getData(), SIMSupplierBo.class) );
    }

    public List<SIMSupplierBo> getSuppliersForTenantAndSuppliers(String tmsTenantId, List<String> supplierIds) {
        List<String> ids = supplierIds.stream().map(s -> tmsTenantId + "-" + s).collect(Collectors.toList());
        Iterable<CachedSupplier> ics = cachedSupplierRepo.findAllById(ids);
        return StreamSupport.stream(ics.spliterator(), false).map(sup -> sup.getData()).map(s -> new Gson().fromJson(s, SIMSupplierBo.class)).collect(Collectors.toList());
    }
}
