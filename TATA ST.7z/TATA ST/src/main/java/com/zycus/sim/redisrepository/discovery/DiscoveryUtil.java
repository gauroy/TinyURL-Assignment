package com.zycus.sim.redisrepository.discovery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.util.Optional;

@Component
public class DiscoveryUtil {

    private static final Logger logger = LoggerFactory.getLogger(DiscoveryUtil.class);

    public Optional<URI> serviceUrl(DiscoveryClient discoveryClient, String serviceName, final String tag) {
        return discoveryClient.getInstances(serviceName).stream()
                .filter(m -> tag == null || tag.isEmpty() || m.getMetadata().containsKey(tag))
                .map(si -> si.getUri()).findFirst();
    }

    public Optional<URI> serviceUrl(DiscoveryClient discoveryClient, String serviceName, final String tag, int pos) {
        return discoveryClient.getInstances(serviceName).stream()
                .filter(m -> tag == null || tag.isEmpty() || m.getMetadata().containsKey(tag))
                .map(si -> si.getUri()).skip(pos - 1).findFirst();
    }
}
