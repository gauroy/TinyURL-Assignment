package com.zycus.sim.redisrepository.service;

import app.zycus.bp.bo.QueryResult;
import app.zycus.bp.bo.constants.SupplierSearchConstants;
import app.zycus.bp.simapi.bo.SIMSupplierBo;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.zycus.sim.api.errors.BadRequestException;
import com.zycus.sim.api.errors.DataFetchException;
import com.zycus.sim.api.errors.DependentServiceUnavailable;
import com.zycus.sim.api.errors.TooManyRequestsException;
import com.zycus.sim.common.event.model.AsyncEvent;
import com.zycus.sim.common.event.queue.QueueAdapter;
import com.zycus.sim.redisrepository.discovery.DiscoveryUtil;
import com.zycus.sim.redisrepository.util.DateDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import javax.annotation.Resource;
import java.net.URI;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Service
public class RedisCacheWriteServiceImpl {

    @Autowired
    DiscoveryClient discoveryClient;

    @Autowired
    RestTemplate restTemplate;

    @Autowired
    RedisCacheServiceHelper helper;

    @Autowired
    DiscoveryUtil discoveryUtil;

    @Value("${sim.search.page-size}")
    private int pageSize;

    @Resource(name = "redisTemplate")
    private ListOperations<String, String> listOps;

	@Value("${sim.redis.processing.queue}")
	private String processingQueue;

	@Value("${server.discovery-host}")
	private String countKey;

    @Value("${server.host}")
	private String host;
    @Value("${server.port}")
    private String port;

	@Autowired
	private QueueAdapter adapter;

    private static final Logger LOGGER = LoggerFactory.getLogger(RedisCacheWriteServiceImpl.class);

    private QueryResult<List<SIMSupplierBo>> loadPagedSuppliersFromSim(String tmsTenantId, int startIndex) {

        String qryStr = new StringBuilder("{\"startIndex\":").append(startIndex).append(
                ",\"recordsPerPage\":").append(pageSize).append(",\"sortColumnName\":-1,\"isAscending\":true,\"reqTotalResultCount\":true,\"escapeCharacter\":\"\\u0000\",\"queryConditions\":[{\"columnName\":48,\"columnValue\":[\"ISUPPLIER_API_ALL_COMPANY_TYPES\"]},{\"columnName\":15,\"columnValue\":true},{\"columnName\":31,\"columnValue\":2}],\"customViewsSet\":{\"customViewsSet\":[\"REGISTRATIONDETAILS\",\"PURCHASINGDETAILS\",\"SMDMMASTERTBL\",\"GLOBALPAYMENTTERMS\",\"BANKINGDETAILS\",\"PAYMENTTERMS\"],\"viewsCriteria\":\"ALL\"},\"tmsClientId\":\"")
                .append(tmsTenantId).append("\"}").toString();
        LOGGER.info(String.format("About to load All Suppliers from SIM for Tenant %s", tmsTenantId));
        return loadDataFromSIM(tmsTenantId, qryStr);
    }

    public boolean lock(String key) {
        if (listOps.getOperations().opsForValue().setIfAbsent(key, "Locked")) {
            listOps.getOperations().expire(key, 60000L, TimeUnit.MILLISECONDS);
            return true;
        }
        return false;
    }

    public long increment(){
        return listOps.getOperations().opsForValue().increment(countKey);
    }
    public long decrement(){
        return listOps.getOperations().opsForValue().decrement(countKey);
    }
    public boolean unlock(String key) {
        return listOps.getOperations().delete(key);
    }


    public long loadAllSuppliersForTenantInRedis(String tmsTenantId, int startIndex) {
        boolean locked = false;
        try {
            locked  = checkIfSyncCanBeRun("LCK-" + tmsTenantId);

            if (startIndex < 1) {
                startIndex = 1;
            }
            LOGGER.info(String.format("About to load suppliers in Cache for Tenant Id %s, startIndex: %d, pageSize: %d", tmsTenantId, startIndex, pageSize));
            QueryResult<List<SIMSupplierBo>> qryResult = loadPagedSuppliersFromSim(tmsTenantId, startIndex);
            long supplierCount = 0L;
            String correlationId = "LOADALLSUPPLIERFORTENANT-" + tmsTenantId + "-" + new Date().getTime();
            while (qryResult != null && qryResult.getResults() != null && !qryResult.getResults().isEmpty()) {
                supplierCount += qryResult.getResults() == null ? 0 : qryResult.getResults().size();
                List<SIMSupplierBo> supplierBolist = qryResult.getResults();
                String msgId = startIndex + "-" + (startIndex + pageSize);
                LOGGER.info(String.format("Syncing %d to %d for %s from Redis. Correlation id:[%s]", startIndex, (startIndex + pageSize), tmsTenantId, correlationId));
                cacheSupplierBOListAndUpdateInQueue(tmsTenantId, correlationId, supplierBolist, msgId, false);
                startIndex += pageSize;
                qryResult = loadPagedSuppliersFromSim(tmsTenantId, startIndex); // Fetch Next Batch
            }
            LOGGER.info(String.format("Successfully Loaded %d suppliers in Cache for Tenant Id %s", supplierCount, tmsTenantId));
            return supplierCount;
        }finally {
            decrement();
            if(locked)
                unlock("LCK-" + tmsTenantId);
        }

    }

    private boolean checkIfSyncCanBeRun(String tmsTenantId) {
        ResponseEntity<String> response = restTemplate.exchange(String.format("http://%s:%s/sim/actuator/health",host,port), HttpMethod.GET,null,String.class);
        if(response.getStatusCode().is2xxSuccessful()){
            Map<String,String> mp = new Gson().fromJson(response.getBody(),new TypeToken<Map<String,String>>(){}.getType());
            if("DOWN".equalsIgnoreCase(mp.get("status"))){
                LOGGER.error("Please try later, Service is currently down! Health:"+response.getBody());
                throw new DependentServiceUnavailable("Please try later, Service is currently down! Health:"+response.getBody());
            }
        }else{
            LOGGER.error("Please try later, Service is currently down! Status Code :"+response.getStatusCode());
            throw new DependentServiceUnavailable("Please try later, Service is currently down! Status Code : "+response.getStatusCode());
        }

        if(increment() > 3) {
            while(decrement()> 3) ;//reset to 3
            LOGGER.error("Please try later max 3 parallel full syncs allowed");
            throw new TooManyRequestsException("Please try later max 3 parallel full syncs allowed");
        }

        if(!lock(tmsTenantId)){
            LOGGER.error("Please try later, Another Full upload is running for tenant "+ tmsTenantId);
            throw new TooManyRequestsException("Please try later,Another Full upload is running for tenant" + tmsTenantId);
        }
        return true;
    }

    private void cacheSupplierBOListAndUpdateInQueue(String tmsTenantId, String correlationId, List<SIMSupplierBo> supplierBolist, String msgId, boolean withSyncData) {
        if (supplierBolist != null && !supplierBolist.isEmpty()) {
            supplierBolist = supplierBolist.stream().filter(s -> "LEGAL_NAME".equals(s.getNameType())).collect(Collectors.toList());
			if (withSyncData)
				pushToQueueForProcessing(tmsTenantId, tmsTenantId + "-" + new Date().getTime(), "RP", supplierBolist,
						processingQueue);
			helper.postToJMSForSolrUpdate(tmsTenantId, msgId, correlationId, supplierBolist);
            helper.saveSuppliers(tmsTenantId, supplierBolist);
            helper.saveExtSuppliers(tmsTenantId, supplierBolist);
            helper.saveDBAs(tmsTenantId, supplierBolist);
			if (withSyncData)
				pushToQueueForProcessing(tmsTenantId, tmsTenantId + "-" + new Date().getTime(), "RS", supplierBolist,
						processingQueue);

        } else {
            LOGGER.info(String.format("No suppliers found to be loaded for tenant %s", tmsTenantId));
        }
    }

	private boolean pushToQueueForProcessing(String tmsTenantId, String msgId, String identifier,
			List<SIMSupplierBo> supplierBolist, String queueName)
	{
		LOGGER.info(String.format(
				"About to push IMT Event for suppliers for Tenant Id %s, supplierBolist: %d, in queueName: %s",
				tmsTenantId, supplierBolist.size(), queueName));
		try
		{
			supplierBolist.stream().map(supplierBo -> supplierBo.getZycusSupplierId()).forEach(zycusSupplierId -> {
				AsyncEvent<Long> asyncEvent = new AsyncEvent<>(tmsTenantId, msgId, tmsTenantId, queueName,
						zycusSupplierId);
				Map<String, Object> map = new HashMap<>();
				map.put("identifier", identifier);
				asyncEvent.setHeader(map);
				adapter.raiseEvent(asyncEvent);
			});
		}
		catch (Exception e)
		{
			LOGGER.error(String.format("Failed to push to queue", e));
			return false;
		}
		return true;
	}



    public long loadSuppliersForTenantInRedis(String tmsTenantId, List<String> supplierIds) {
        int startIndex = 0;
        long supplierCount = 0L;
        LOGGER.info(String.format("About to Load %d suppliers [%s] for Tenant %s", supplierIds.size(), String.join(",", supplierIds), tmsTenantId));
        while (startIndex == 0 || startIndex < supplierIds.size()) {
            int endIndex = (startIndex + 1000) < supplierIds.size() ? startIndex + 1000 : supplierIds.size();
            QueryResult<List<SIMSupplierBo>> qryResult = load1000SuppliersFromSimBySupplierIds(tmsTenantId,
                    supplierIds.subList(startIndex, endIndex));
            String correlationId = "LOADSUPPLIERFORTENANT-" + tmsTenantId + "-" + new Date().getTime();
            List<SIMSupplierBo> supplierBolist = qryResult.getResults();
            supplierCount += supplierBolist == null ? 0 : supplierBolist.size();
            String msgId = startIndex + "-" + endIndex;
            cacheSupplierBOListAndUpdateInQueue(tmsTenantId, correlationId, supplierBolist, msgId, true);
            startIndex += 1000;
        }
        LOGGER.info(String.format("Successfully Loaded %d suppliers in Cache for Tenant Id %s", supplierCount, tmsTenantId));
        return supplierCount;
    }

    private QueryResult<List<SIMSupplierBo>> load1000SuppliersFromSimBySupplierIds(String tmsTenantId, List<String> subList) {

        String qryStr = new StringBuilder(
                "{\"recordsPerPage\":-1,\"sortColumnName\":-1,\"isAscending\":true,\"reqTotalResultCount\":true,\"escapeCharacter\":\"\\u0000\",\"queryConditions\":[{\"columnName\":")
                .append(SupplierSearchConstants.SEARCH_IN_DBA_IDS).append(",\"columnValue\":[")
                .append(subList.stream().collect(Collectors.joining(",")))
                .append("]},{\"columnName\":48,\"columnValue\":[\"ISUPPLIER_API_ALL_COMPANY_TYPES\"]},{\"columnName\":15,\"columnValue\":true},{\"columnName\":31,\"columnValue\":2}],\"customViewsSet\":{\"customViewsSet\":[\"REGISTRATIONDETAILS\",\"PURCHASINGDETAILS\",\"SMDMMASTERTBL\",\"GLOBALPAYMENTTERMS\",\"BANKINGDETAILS\",\"PAYMENTTERMS\"],\"viewsCriteria\":\"ALL\"},\"tmsClientId\":\"")
                .append(tmsTenantId).append("\"}").toString();
        LOGGER.info(String.format("About to load %s Suppliers from SIM for Tenant %s", String.join(",", subList), tmsTenantId));
        return loadDataFromSIM(tmsTenantId, qryStr);
    }

    private QueryResult<List<SIMSupplierBo>> loadDataFromSIM(String tmsTenantId, String qryStr) {
        LOGGER.debug(qryStr);

        Optional<URI> uri = discoveryUtil.serviceUrl(discoveryClient, "sim", tmsTenantId);
        boolean retry = false;
        int cnt = 1;
        do {
            if (!uri.isPresent()) {
                LOGGER.error(String.format("SIM URL Serving Tenant %s not Found in Consul", tmsTenantId));
                if (retry) { //exhausted all urls but at least one url found but not working
                    throw new DataFetchException(String.format("Failed to load Data from SIM, no working URL serving Tenant %s found in consul", tmsTenantId));
                } else { //first time no url
                    throw new DependentServiceUnavailable(String.format("SIM URL Serving Tenant %s not Found in Consul", tmsTenantId));
                }
            }
            LOGGER.info(String.format("URI Found %s, tenantid %s", uri.get().toString(), tmsTenantId));
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.set("Authorization", "Basic " + "xxxxxxxxxxxx");
            headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
            HttpEntity<String> entity = new HttpEntity<String>(qryStr, headers);
            Class<QueryResult<List<SIMSupplierBo>>> clazz = (Class) QueryResult.class;
            try {
                ResponseEntity<String> response = restTemplate.exchange(
                        uri.get().toString() + "/sim/api_v1/suppliersearchws.do", HttpMethod.POST, entity, String.class);

                if (response.getStatusCode().is2xxSuccessful()) {
                    return buidFromJson(response);
                } else {
                    LOGGER.error(String.format("Failed to load Data from SIM for query %s", qryStr));
                    throw new DataFetchException("Failed to load Data from SIM");
                }
            } catch (RestClientResponseException ex) { //Failed to execute Rest request retry to find another healthy url
                LOGGER.error(String.format("Failed to load Data from SIM for query %s", qryStr), ex);
                LOGGER.warn(String.format("Retry No %d to find healty SIM service serving %s, ", ++cnt, qryStr));
                uri = discoveryUtil.serviceUrl(discoveryClient, "sim", tmsTenantId, cnt);
            } catch (Exception ex) {
                LOGGER.error(String.format("Failed to load Data from SIM for query %s", qryStr), ex);
                throw new DataFetchException("Failed to load Data from SIM", ex);
            }

        } while (true);
    }


    private QueryResult<List<SIMSupplierBo>> buidFromJson(ResponseEntity<String> response) {
        GsonBuilder gsonBuilder = new GsonBuilder().registerTypeAdapter(Date.class, new DateDeserializer());
        Gson gson = gsonBuilder.create();
        return gson.fromJson(response.getBody(), new TypeToken<QueryResult<List<SIMSupplierBo>>>() {
        }.getType());
    }

    public long syncAllSuppliersForTenantWithSolr(String tmsTenantId) {
        boolean locked = false;
        try {
            locked  = checkIfSyncCanBeRun("LCK-" + tmsTenantId);
            LOGGER.info(String.format("Syncing all Supplier for %s from Redis", tmsTenantId));
            int page = 0;
            Page<SIMSupplierBo> pg = helper.getSuppliersForTenant(tmsTenantId, PageRequest.of(page, pageSize));
            int totalPages = pg.getTotalPages();
            long totalCount = pg.getTotalElements();
            String correlationId = "SYNCALLSUPPLIERFORTENANT-" + tmsTenantId + "-" + new Date().getTime();
            LOGGER.info(String.format("Found %d Suppliers for %s from Redis", totalCount, tmsTenantId));
            while (page < totalPages) {
                int from = page * pageSize + 1;
                int to = (page * pageSize) + pg.getSize();
                LOGGER.info(String.format("Syncing %d to %d of %d for %s from Redis. Correlation id:[%s]", from, to, totalCount, tmsTenantId, correlationId));
                helper.postToJMSForSolrUpdate(tmsTenantId, from + "-" + to, correlationId, pg.getContent());
                pg = helper.getSuppliersForTenant(tmsTenantId, PageRequest.of(++page, pageSize));
            }
            return totalCount;
        } finally {
            decrement();
            if(locked)
                unlock("LCK-" + tmsTenantId);
        }

    }

    public int syncSuppliersForTenantWithSolr(String tmsTenantId, List<String> supplierIds) {
        if(supplierIds.size() >  pageSize){
            throw new BadRequestException(String.format("Max %d items can be processed at one time",pageSize));
        }
        String correlationId = "SYNCSUPPLIERSFORTENANT-" + tmsTenantId + "-" + new Date().getTime();
        LOGGER.info(String.format("Syncing [%s] Suppliers for %s. Correlation id:[%s]", String.join(",", supplierIds), tmsTenantId, correlationId));
        List<SIMSupplierBo> supplierBolist = helper.getSuppliersForTenantAndSuppliers(tmsTenantId, supplierIds);
        helper.postToJMSForSolrUpdate(tmsTenantId, "1-"+supplierIds.size(), UUID.randomUUID().toString(), supplierBolist);
        return supplierBolist.size();
    }


}
