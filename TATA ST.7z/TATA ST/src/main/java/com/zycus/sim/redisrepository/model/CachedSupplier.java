package com.zycus.sim.redisrepository.model;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Transient;
import org.springframework.data.redis.core.RedisHash;

import com.google.gson.Gson;

import app.zycus.bp.simapi.bo.SIMSupplierBo;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.redis.core.index.Indexed;


@Getter
@Setter
@AllArgsConstructor
@RedisHash("suppliers")
public class CachedSupplier implements Serializable {
	@Transient
	private static final SimpleDateFormat SDF =new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS");
	
	@Id
	private String id;
	@Indexed
	private String tmsClientId;
	
	private long zycusSupplierId;
	
	private long simClientId;
	
	private long gsId;
	
	private int supplierType;
	
	private int supplierStatus;
	private int approvalStatus;
	
	
	private String createDate;
	private String modifiedDate;
	
	private String taxId;
	private String taxIdFormat;
	private String nameType;
	private String name;
	private long plantId;
	private String systemCode;
	
	private String data ="";
	
	
	
	
	
	public CachedSupplier() {
		
	}


	

	public CachedSupplier(String tmsTenantId, SIMSupplierBo bo) {
		tmsClientId = tmsTenantId;
		id = tmsClientId + "-" +bo.getZycusSupplierId();
		zycusSupplierId=bo.getZycusSupplierId();
		simClientId=bo.getSimClientId();
		gsId=bo.getGsId();
		supplierType=bo.getSupplierType();
		supplierStatus=bo.getSupplierStatus();
		approvalStatus=bo.getApprovalStatus();
		createDate=bo.getCreateDate() != null ?SDF.format(bo.getCreateDate()): null;
		modifiedDate=bo.getModifiedDate() != null? SDF.format(bo.getModifiedDate()): null;
		taxId=bo.getTaxId();
		taxIdFormat=bo.getTaxIdFormat();
		nameType=bo.getNameType();
		name=bo.getName();
		plantId=bo.getPlantId();
		systemCode=bo.getSystemCode();
		data = new Gson().toJson(bo);
		
	}
	
}
