package com.zycus.sim.redisrepository.service;

import app.zycus.bp.bo.QueryResult;
import app.zycus.bp.bo.constants.SupplierSearchConstants;
import app.zycus.bp.simapi.bo.SIMSupplierBo;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.zycus.sim.api.errors.DataFetchException;
import com.zycus.sim.api.errors.DependentServiceUnavailable;
import com.zycus.sim.redisrepository.discovery.DiscoveryUtil;
import com.zycus.sim.redisrepository.model.CachedSupplier;
import com.zycus.sim.redisrepository.util.DateDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class SupplierServiceImpl implements ISupplierService
{
	private static final Logger logger = LoggerFactory.getLogger(SupplierServiceImpl.class);

	@Autowired
	DiscoveryUtil discoveryUtil;

	@Autowired
	DiscoveryClient discoveryClient;

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	RedisCacheWriteServiceImpl redisWriteCacheService;

	@Override
	public List<CachedSupplier> findSupplierBySupplierIdFromSIM(String tmsTenantId, List<String> supplierIds)
	{
		String critriaQuery = getCriteriaQuery(tmsTenantId, supplierIds);
		String dbSupplierIds = null;
		QueryResult<List<SIMSupplierBo>> suppliers = loadDataFromSIM(tmsTenantId, critriaQuery);

		if (suppliers != null)
		{
			try {
				dbSupplierIds = Arrays.toString(supplierIds.toArray());
				logger.info("Caching missed supplierId back to redis for tenantId: {}, supplierIds:{}", tmsTenantId, dbSupplierIds);
				redisWriteCacheService.loadSuppliersForTenantInRedis(tmsTenantId, supplierIds);
			} catch (Exception e) {
				logger.error("[HARMLESS] Failed to cache missed supplierId back to redis for tenantId: {}, supplierIds:{}", tmsTenantId, dbSupplierIds, e);
			}
			return mapSIMSupplierBOToCachedSupplier(tmsTenantId, suppliers.getResults());
		}

		return null;

	}

	@Override
	public CachedSupplier findSuppliersByERPIdsFromSIM(String tmsTenantId, String erpIds)
	{
		return null;
	}

	@Override
	public CachedSupplier findSupplierByDBAIdFromSIM(String tmsTenantId, String erpIds)
	{
		return null;
	}

	private String getCriteriaQuery(String tmsTenantId, List<String> supplierIds)
	{
		return new StringBuilder(
				"{\"recordsPerPage\":-1,\"sortColumnName\":-1,\"isAscending\":true,\"reqTotalResultCount\":true,\"escapeCharacter\":\"\\u0000\",\"queryConditions\":[{\"columnName\":")
				.append(SupplierSearchConstants.SEARCH_IN_DBA_IDS).append(",\"columnValue\":[")
				.append(supplierIds.stream().collect(Collectors.joining(",")))
				.append("]},{\"columnName\":48,\"columnValue\":[\"ISUPPLIER_API_ALL_COMPANY_TYPES\"]},{\"columnName\":15,\"columnValue\":true},{\"columnName\":31,\"columnValue\":2}],\"customViewsSet\":{\"customViewsSet\":[\"REGISTRATIONDETAILS\",\"PURCHASINGDETAILS\",\"SMDMMASTERTBL\",\"GLOBALPAYMENTTERMS\",\"BANKINGDETAILS\",\"PAYMENTTERMS\"],\"viewsCriteria\":\"ALL\"},\"tmsClientId\":\"")
				.append(tmsTenantId).append("\"}").toString();
	}

	private QueryResult<List<SIMSupplierBo>> loadDataFromSIM(String tmsTenantId, String qryStr)
	{
		logger.debug(qryStr);

		Optional<URI> uri = discoveryUtil.serviceUrl(discoveryClient, "sim", tmsTenantId);
		boolean retry = false;
		int cnt = 1;
		if (!uri.isPresent())
		{
			logger.error(String.format("SIM URL Serving Tenant %s not Found in Consul", tmsTenantId));
			if (retry)
			{ //exhausted all urls but at least one url found but not working
				throw new DataFetchException(
						String.format("Failed to load Data from SIM, no working URL serving Tenant %s found in consul",
								tmsTenantId));
			}
			else
			{ //first time no url
				throw new DependentServiceUnavailable(
						String.format("SIM URL Serving Tenant %s not Found in Consul", tmsTenantId));
			}
		}
		logger.info(String.format("URI Found %s, tenantid %s", uri.get().toString(), tmsTenantId));
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", "Basic " + "xxxxxxxxxxxx");
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity = new HttpEntity<String>(qryStr, headers);
		Class<QueryResult<List<SIMSupplierBo>>> clazz = (Class) QueryResult.class;
		try
		{
            ResponseEntity<String> response = restTemplate.exchange(
                    uri.get().toString() + "/sim/api_v1/suppliersearchws.do", HttpMethod.POST, entity, String.class);

			if (response.getStatusCode().is2xxSuccessful())
			{
				return buidFromJson(response);
			}
			else
			{
				logger.error(String.format("Failed to load Data from SIM for query %s", qryStr));
				throw new DataFetchException("Failed to load Data from SIM");
			}
		}
		catch (RestClientResponseException ex)
		{ //Failed to execute Rest request retry to find another healthy url
			logger.error(String.format("Failed to load Data from SIM for query %s", qryStr), ex);
			logger.warn(String.format("Retry No %d to find healty SIM service serving %s, ", ++cnt, qryStr));
			uri = discoveryUtil.serviceUrl(discoveryClient, "sim", tmsTenantId, cnt);
		}
		catch (Exception ex)
		{
			logger.error(String.format("Failed to load Data from SIM for query %s", qryStr), ex);
			throw new DataFetchException("Failed to load Data from SIM", ex);
		}

		return null;
	}

	private QueryResult<List<SIMSupplierBo>> buidFromJson(ResponseEntity<String> response)
	{
		GsonBuilder gsonBuilder = new GsonBuilder().registerTypeAdapter(Date.class, new DateDeserializer());
		Gson gson = gsonBuilder.create();
		return gson.fromJson(response.getBody(), new TypeToken<QueryResult<List<SIMSupplierBo>>>()
		{
		}.getType());
	}

	private List<CachedSupplier> mapSIMSupplierBOToCachedSupplier(String tmsTenantId, List<SIMSupplierBo> suppliers)
	{
		return suppliers.stream().map(supplier -> new CachedSupplier(tmsTenantId, supplier))
				.collect(Collectors.toList());
	}

}
