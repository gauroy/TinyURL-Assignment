package com.zycus.sim.redisrepository.repository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.zycus.sim.redisrepository.controller.CacheSupplierController;
import com.zycus.sim.redisrepository.model.ExtSupplier;

@Repository
public interface ExtSupplierRepository extends CrudRepository<ExtSupplier, String> {

	
	
}
