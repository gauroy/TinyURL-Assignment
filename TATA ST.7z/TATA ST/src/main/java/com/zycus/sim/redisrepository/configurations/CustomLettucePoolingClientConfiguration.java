package com.zycus.sim.redisrepository.configurations;

import java.time.Duration;
import java.util.Optional;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration;
import org.springframework.data.redis.connection.lettuce.LettucePoolingClientConfiguration;

import io.lettuce.core.ClientOptions;
import io.lettuce.core.ReadFrom;
import io.lettuce.core.resource.ClientResources;

@SuppressWarnings("rawtypes")
public class CustomLettucePoolingClientConfiguration implements LettucePoolingClientConfiguration {

	private final LettuceClientConfiguration clientConfiguration;
	private final GenericObjectPoolConfig poolConfig;

	public CustomLettucePoolingClientConfiguration(LettuceClientConfiguration clientConfiguration,
			GenericObjectPoolConfig poolConfig) {
		this.clientConfiguration = clientConfiguration;
		this.poolConfig = poolConfig;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration#
	 * isUseSsl()
	 */
	@Override
	public boolean isUseSsl() {
		return clientConfiguration.isUseSsl();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration#
	 * isVerifyPeer()
	 */
	@Override
	public boolean isVerifyPeer() {
		return clientConfiguration.isVerifyPeer();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration#
	 * isStartTls()
	 */
	@Override
	public boolean isStartTls() {
		return clientConfiguration.isStartTls();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration#
	 * getClientResources()
	 */
	@Override
	public Optional<ClientResources> getClientResources() {
		return clientConfiguration.getClientResources();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration#
	 * getClientOptions()
	 */
	@Override
	public Optional<ClientOptions> getClientOptions() {
		return clientConfiguration.getClientOptions();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration#
	 * getClientName()
	 */
	@Override
	public Optional<String> getClientName() {
		return clientConfiguration.getClientName();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration#
	 * getReadFrom()
	 */
	@Override
	public Optional<ReadFrom> getReadFrom() {
		return clientConfiguration.getReadFrom();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration#
	 * getCommandTimeout()
	 */
	@Override
	public Duration getCommandTimeout() {
		return clientConfiguration.getCommandTimeout();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration#
	 * getShutdownTimeout()
	 */
	@Override
	public Duration getShutdownTimeout() {
		return clientConfiguration.getShutdownTimeout();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.data.redis.connection.lettuce.LettuceClientConfiguration.
	 * LettucePoolingClientConfiguration#getPoolConfig()
	 */
	@Override
	public GenericObjectPoolConfig getPoolConfig() {
		return poolConfig;
	}

	@Override
	public Duration getShutdownQuietPeriod() {
		// TODO Auto-generated method stub
		return null;
	}
}