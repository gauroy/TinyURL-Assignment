package com.zycus.sim.redisrepository;

import com.zycus.sim.common.event.queue.QueueAdapter;
import com.zycus.sim.redisrepository.jmslisteners.SupplierChangeListener;
import com.zycus.sim.redisrepository.service.RedisCacheWriteServiceImpl;
import org.apache.activemq.ActiveMQConnectionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Primary;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.connection.SingleConnectionFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.web.client.RestTemplate;

import javax.annotation.PostConstruct;
import javax.jms.ConnectionFactory;

@SpringBootApplication
@EnableDiscoveryClient
@EnableJms
@ComponentScan(basePackages = {
        "com.zycus.sim"
})
public class RedisRepositoryApplication {

	private static final Logger logger             = LoggerFactory.getLogger(RedisRepositoryApplication.class);
    public static final String TOPIC_SIM_SUPPLIER = "topic.sim_supplier";

    private static final String logo = "Starting Application" +
            "\n       .__                                     .___.__                                                    .__  __                       \n" +
            "  _____|__| _____           _______   ____   __| _/|__| ______         _______   ____ ______   ____  _____|__|/  |_  ___________ ___.__.\n" +
            " /  ___/  |/     \\   ______ \\_  __ \\_/ __ \\ / __ | |  |/  ___/  ______ \\_  __ \\_/ __ \\\\____ \\ /  _ \\/  ___/  \\   __\\/  _ \\_  __ <   |  |\n" +
            " \\___ \\|  |  Y Y  \\ /_____/  |  | \\/\\  ___// /_/ | |  |\\___ \\  /_____/  |  | \\/\\  ___/|  |_> >  <_> )___ \\|  ||  | (  <_> )  | \\/\\___  |\n" +
            "/____  >__|__|_|  /          |__|    \\___  >____ | |__/____  >          |__|    \\___  >   __/ \\____/____  >__||__|  \\____/|__|   / ____|\n" +
            "     \\/         \\/                       \\/     \\/         \\/                       \\/|__|              \\/                       \\/     ";

	public static void main(String[] args)
	{
        logger.info(logo);
        SpringApplication.run(RedisRepositoryApplication.class, args);
    }

    @Value("${spring.activemq.broker-url}")
    private String commonJMSUrl;


    @Value("${spring.activemq.dedicated.broker-url}")
    private String dedicatedJMSUrl;

    @Value("${enable-ids:true}")
    private Boolean isIdsEnabled;

	@Value("${server.discovery-host}")
	private String countKey;

	@Autowired
	private RedisTemplate<String, String> redisTemplate;

	@Autowired
	private RedisCacheWriteServiceImpl service;

	@Autowired
	private QueueAdapter adapter;


    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

    @Bean
    @Primary
    public ConnectionFactory jmsConnectionFactory() {
        ConnectionFactory connectionFactory = new SingleConnectionFactory(new ActiveMQConnectionFactory(dedicatedJMSUrl));
        return connectionFactory;
    }

    @Bean
    public ConnectionFactory commonJmsConnectionFactory2() {
        ConnectionFactory connectionFactory = new SingleConnectionFactory(new ActiveMQConnectionFactory(commonJMSUrl));
        return connectionFactory;
    }

    @Bean
    @Primary
    public JmsTemplate jmsTemplate() {
        JmsTemplate jmsTemplate = new JmsTemplate();
        jmsTemplate.setConnectionFactory(jmsConnectionFactory());
		jmsTemplate.setDefaultDestinationName(TOPIC_SIM_SUPPLIER);
        return jmsTemplate;
    }


    @Bean(name="commonJMS")
    public JmsTemplate commonJMSTemplate(){
        JmsTemplate jmsTemplate = new JmsTemplate();
        jmsTemplate.setConnectionFactory(commonJmsConnectionFactory2());
		jmsTemplate.setDefaultDestinationName(TOPIC_SIM_SUPPLIER);
        return jmsTemplate;
    }


    @PostConstruct
    public void init() {
        if (!isIdsEnabled) {
            logger.info("IDS is NOT enabled, so subscribing to queue {}", TOPIC_SIM_SUPPLIER);
            redisTemplate.delete(countKey);
            adapter.bindFunctionToExchange("commonJMS", TOPIC_SIM_SUPPLIER, "REDISREPO", new SupplierChangeListener(service));
            logger.info(String.format("Listening to REDISREPO.%s Queue", TOPIC_SIM_SUPPLIER));
        } else {
            logger.info("IDS is enabled, so NOT subscribing to queue {}", TOPIC_SIM_SUPPLIER);
        }
    }


}
