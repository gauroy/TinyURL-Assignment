package com.zycus.sim.redisrepository.repository;

import org.springframework.data.repository.CrudRepository;

import com.zycus.sim.redisrepository.model.CachedDBA;

public interface CachedDBARepository extends CrudRepository<CachedDBA, String> {

}
