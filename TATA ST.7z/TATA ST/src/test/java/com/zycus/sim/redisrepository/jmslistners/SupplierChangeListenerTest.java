package com.zycus.sim.redisrepository.jmslistners;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.jms.JMSException;
import javax.jms.ObjectMessage;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import com.zycus.sim.redisrepository.jmslisteners.SupplierChangeListener;
import com.zycus.sim.redisrepository.service.RedisCacheWriteServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class SupplierChangeListenerTest {

	@Mock
	private RedisCacheWriteServiceImpl service;
	
	@Mock
	private ObjectMessage message;
	
	@InjectMocks
	private SupplierChangeListener supplierChangeListner;
	
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void applyLockIsTrue() throws JMSException {
		List<String> list = new ArrayList<>();
		HashMap<String, Object> map =new HashMap<>();
		map.put("TMS_CLIENTID", "abc");
		map.put("LIST_OF_SUPPLIERID", list);		
		Mockito.when(service.lock(null)).thenReturn(true);
		Mockito.when(service.unlock(null)).thenReturn(true);
		Mockito.when(message.getObject()).thenReturn(map);
		assertTrue(supplierChangeListner.apply(message));
		Mockito.verify(service).lock(null);
		Mockito.verify(service).loadSuppliersForTenantInRedis("abc",list);
		Mockito.verify(service).unlock(null);
	}

	@Test
	public void applyLockIsFalse() throws JMSException {
		HashMap<String, Object> map =new HashMap<>();
		map.put("TMS_CLIENTID", "abc");
		map.put("LIST_OF_SUPPLIERID", new ArrayList<String>());
		Mockito.when(service.lock(null)).thenReturn(false);
		assertTrue(supplierChangeListner.apply(message));
	}
	
	
	@Test
	public void applyThrowException() throws JMSException {
		HashMap<String, Object> map =new HashMap<>();
		map.put("TMS_CLIENTID", "abc");
		map.put("LIST_OF_SUPPLIERID", new ArrayList<String>());
		Mockito.when(service.lock(null)).thenReturn(true);
		Mockito.when(message.getObject()).thenThrow(RuntimeException.class);
		assertFalse(supplierChangeListner.apply(message));
	}
}
