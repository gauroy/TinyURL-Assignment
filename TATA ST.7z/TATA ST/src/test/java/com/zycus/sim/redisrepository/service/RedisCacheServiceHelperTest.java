package com.zycus.sim.redisrepository.service;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.google.gson.Gson;
import com.zycus.sim.common.event.queue.QueueAdapter;
import com.zycus.sim.redisrepository.model.CachedSupplier;
import com.zycus.sim.redisrepository.repository.CachedDBARepository;
import com.zycus.sim.redisrepository.repository.CachedSupplierRepository;
import com.zycus.sim.redisrepository.repository.ExtSupplierRepository;

import app.zycus.bp.simapi.bo.CompanyDetails;
import app.zycus.bp.simapi.bo.DBAAlias;
import app.zycus.bp.simapi.bo.ERPDetailsBO;
import app.zycus.bp.simapi.bo.SIMSupplierBo;
import app.zycus.bp.simapi.bo.SupplierProfile;

public class RedisCacheServiceHelperTest {

	@Mock
	CachedSupplierRepository cachedSupplierRepo;

	@Mock
	ExtSupplierRepository extSupplierRepo;

	@Mock
	CachedDBARepository cachedDBARepo;

	@Mock
	QueueAdapter adapter;
	
	@InjectMocks
	RedisCacheServiceHelper redisCacheServiceHelper;

	
	String queueName;
	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void saveExtSuppliers() {
		redisCacheServiceHelper.saveExtSuppliers("123", new ArrayList<SIMSupplierBo>());
		Mockito.verify(extSupplierRepo,Mockito.times(1)).saveAll(Mockito.anyIterable());
		
	}
	
	
	@Test
	public void saveExtSuppliersListWithDataErpDetailsNull() {
		List<SIMSupplierBo> listSupplierBos = new ArrayList<SIMSupplierBo>();
		SIMSupplierBo simSupplierBo = new SIMSupplierBo();
		SupplierProfile profile =new SupplierProfile();
		CompanyDetails companyDetails = new CompanyDetails();
		companyDetails.setErpDetailsList(new ArrayList<ERPDetailsBO>());
		profile.setCompanyDetails(companyDetails);
		simSupplierBo.setSupplierProfile(profile);
		listSupplierBos.add(simSupplierBo);		
		redisCacheServiceHelper.saveExtSuppliers("123", listSupplierBos);
		Mockito.verify(extSupplierRepo,Mockito.times(1)).saveAll(Mockito.anyIterable());
		
	}
	
	@Test
	public void saveExtSuppliersListWithDataErpDetailsWithData() {
		List<SIMSupplierBo> listSupplierBos = new ArrayList<SIMSupplierBo>();
		SIMSupplierBo simSupplierBo = new SIMSupplierBo();
		simSupplierBo.setZycusSupplierId(123L);
		SupplierProfile profile =new SupplierProfile();
		CompanyDetails companyDetails = new CompanyDetails();
		List<ERPDetailsBO> erpDetailsList = new ArrayList<ERPDetailsBO>();
		ERPDetailsBO erpDetailsBO = new ERPDetailsBO();
		erpDetailsBO.setErpId("abc");
		erpDetailsList.add(erpDetailsBO);
		companyDetails.setErpDetailsList(erpDetailsList);
		profile.setCompanyDetails(companyDetails);
		simSupplierBo.setSupplierProfile(profile);
		listSupplierBos.add(simSupplierBo);		
		redisCacheServiceHelper.saveExtSuppliers("123", listSupplierBos);
		Mockito.verify(extSupplierRepo,Mockito.times(1)).saveAll(Mockito.anyIterable());
		
	}
	
	@Test
	public void saveExtSuppliersListWithDataErpDetailsWithIdNull() {
		List<SIMSupplierBo> listSupplierBos = new ArrayList<SIMSupplierBo>();
		SIMSupplierBo simSupplierBo = new SIMSupplierBo();
		simSupplierBo.setZycusSupplierId(123L);
		SupplierProfile profile =new SupplierProfile();
		CompanyDetails companyDetails = new CompanyDetails();
		List<ERPDetailsBO> erpDetailsList = new ArrayList<ERPDetailsBO>();
		ERPDetailsBO erpDetailsBO = new ERPDetailsBO();
		erpDetailsBO.setErpId(null);
		erpDetailsList.add(erpDetailsBO);
		companyDetails.setErpDetailsList(erpDetailsList);
		profile.setCompanyDetails(companyDetails);
		simSupplierBo.setSupplierProfile(profile);
		listSupplierBos.add(simSupplierBo);		
		redisCacheServiceHelper.saveExtSuppliers("123", listSupplierBos);
		Mockito.verify(extSupplierRepo,Mockito.times(1)).saveAll(Mockito.anyIterable());
		
	}
	
	@Test
	public void saveExtSuppliersListWithDataErpDetailsWithIdEmpty() {
		List<SIMSupplierBo> listSupplierBos = new ArrayList<SIMSupplierBo>();
		SIMSupplierBo simSupplierBo = new SIMSupplierBo();
		simSupplierBo.setZycusSupplierId(123L);
		SupplierProfile profile =new SupplierProfile();
		CompanyDetails companyDetails = new CompanyDetails();
		List<ERPDetailsBO> erpDetailsList = new ArrayList<ERPDetailsBO>();
		ERPDetailsBO erpDetailsBO = new ERPDetailsBO();
		erpDetailsBO.setErpId("");
		erpDetailsList.add(erpDetailsBO);
		companyDetails.setErpDetailsList(erpDetailsList);
		profile.setCompanyDetails(companyDetails);
		simSupplierBo.setSupplierProfile(profile);
		listSupplierBos.add(simSupplierBo);		
		redisCacheServiceHelper.saveExtSuppliers("123", listSupplierBos);
		Mockito.verify(extSupplierRepo,Mockito.times(1)).saveAll(Mockito.anyIterable());
		
	}
	
	@Test
	public void saveSuppliers(){
		List<SIMSupplierBo> simSupplierBos = new ArrayList<>();
		SIMSupplierBo simSupplierBo = new SIMSupplierBo();
		simSupplierBo.setZycusSupplierId(123L);
		simSupplierBo.setName("xyz");
		SupplierProfile profile =new SupplierProfile();
		List<DBAAlias> aliasList = new ArrayList<>();
		DBAAlias dbaAlias = new DBAAlias();
		dbaAlias.setdbaid("abc");
		dbaAlias.setname("cde");
		aliasList.add(dbaAlias);
		profile.setDbaAlias(aliasList);
		simSupplierBo.setSupplierProfile(profile);
		simSupplierBos.add(simSupplierBo);
		redisCacheServiceHelper.saveSuppliers("abc", simSupplierBos);
		Mockito.verify(cachedSupplierRepo).saveAll(Mockito.anyIterable());
	}
	
	@Test
	public void saveDBAs(){
		List<SIMSupplierBo> simSupplierBos = new ArrayList<>();
		SIMSupplierBo simSupplierBo = new SIMSupplierBo();
		simSupplierBo.setZycusSupplierId(123L);
		simSupplierBo.setName("xyz");
		SupplierProfile profile =new SupplierProfile();
		List<DBAAlias> aliasList = new ArrayList<>();
		DBAAlias dbaAlias = new DBAAlias();
		dbaAlias.setdbaid("abc");
		dbaAlias.setname("cde");
		aliasList.add(dbaAlias);
		profile.setDbaAlias(aliasList);
		simSupplierBo.setSupplierProfile(profile);
		simSupplierBos.add(simSupplierBo);
		redisCacheServiceHelper.saveDBAs("123", simSupplierBos);
		Mockito.verify(cachedDBARepo).saveAll(Mockito.anyIterable());
	}
	@Test
 	public void testGetSuppliersForTenant(){
		List<CachedSupplier> simSupplierBos = new ArrayList<>();
		SIMSupplierBo simSupplierBo = new SIMSupplierBo();
		simSupplierBo.setTmsUserId("123");
		CachedSupplier cachedSupplier = new CachedSupplier();
		cachedSupplier.setData(new Gson().toJson(simSupplierBo,SIMSupplierBo.class));
		cachedSupplier.setTmsClientId("123");
		simSupplierBos.add(cachedSupplier);		
		Mockito.when(cachedSupplierRepo.findByTmsClientId("123")).thenReturn(simSupplierBos);
		assertEquals(1,redisCacheServiceHelper.getSuppliersForTenant("123").size());
	}

	@Test
	public void testSuppliersForTenantAndSuppliers(){
		List<CachedSupplier> simSupplierBos = new ArrayList<>();
		simSupplierBos.add(new CachedSupplier());		
		Mockito.when(cachedSupplierRepo.findAllById(Mockito.anyList())).thenReturn( (Iterable) simSupplierBos);
		assertEquals(1,redisCacheServiceHelper.getSuppliersForTenantAndSuppliers("123", Arrays.asList(new String[]{"Sup1"})).size());
	}
}
