package com.zycus.sim.redisrepository.controller;

import java.util.ArrayList;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import com.zycus.sim.api.errors.NoResourceFoundException;
import com.zycus.sim.api.errors.RequiredParametersMissing;
import com.zycus.sim.redisrepository.service.RedisCacheReadServiceImpl;

import app.zycus.bp.simapi.bo.ContactDetails;

@RunWith(MockitoJUnitRunner.class)
public class ContactsControllerTest {

	@Mock
	private RedisCacheReadServiceImpl redisCacheReadServiceImpl;

	@InjectMocks
	private ContactsController contactsController;

	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test(expected = RequiredParametersMissing.class)
	public void testFindContactsByEmailAndDBAWhenTmsClientIdIsNull() {
		contactsController.findContactsByEmailAndDBA(null, "john@zycus.com", new ArrayList<>());
	}

	@Test(expected = RequiredParametersMissing.class)
	public void testFindContactsByEmailAndDBAWhenTmsClientIdIsEmpty() {
		contactsController.findContactsByEmailAndDBA("", "john@zycus.com", new ArrayList<>());
	}

	@Test(expected = RequiredParametersMissing.class)
	public void testFindContactsByEmailAndDBAWhenEmailIdIsNull() {
		contactsController.findContactsByEmailAndDBA("abc", null, new ArrayList<>());
	}

	@Test(expected = RequiredParametersMissing.class)
	public void testFindContactsByEmailAndDBAWhenEmailIdIsEmpty() {
		contactsController.findContactsByEmailAndDBA("abc", "", new ArrayList<>());
	}

	@Test(expected = RequiredParametersMissing.class)
	public void testFindContactsByEmailAndDBAWhenDBAIdIsNull() {
		contactsController.findContactsByEmailAndDBA("abc", "john@zycus.com", null);
	}

	@Test(expected = RequiredParametersMissing.class)
	public void testFindContactsByEmailAndDBAWhenDBAIdIsEmpty() {
		contactsController.findContactsByEmailAndDBA("abc", "john@zycus.com", new ArrayList<>());
	}

	@Test(expected = NoResourceFoundException.class)
	public void testFindContactsByEmailAndDBAWhenRetValueIsNull() {
		ArrayList<String> dbaIds = new ArrayList<>();
		dbaIds.add("abc");
		Mockito.when(redisCacheReadServiceImpl.findAllContactsByDBAIdsAndEmail(Mockito.anyString(), Mockito.anyString(),
				Mockito.any(ArrayList.class))).thenReturn(null);
		contactsController.findContactsByEmailAndDBA("abc", "john@zycus.com", dbaIds);
	}

	@Test(expected = NoResourceFoundException.class)
	public void testFindContactsByEmailAndDBAWhenContactsIsEmpty() {
		ArrayList<String> dbaIds = new ArrayList<>();
		dbaIds.add("abc");
		contactsController.findContactsByEmailAndDBA("abc", "john@zycus.com", dbaIds);
	}

	@Test
	public void testFindContactsByEmailAndDBAWhenContactsValid() {
		ArrayList<ContactDetails> details = new ArrayList<>();
		details.add(new ContactDetails());
		Mockito.when(redisCacheReadServiceImpl.findAllContactsByDBAIdsAndEmail(Mockito.anyString(), Mockito.anyString(),
				Mockito.any(ArrayList.class))).thenReturn(details);
		ArrayList<String> dbaIds = new ArrayList<>();
		dbaIds.add("abc");
		contactsController.findContactsByEmailAndDBA("abc", "john@zycus.com", dbaIds);
	}

}
