package com.zycus.sim.redisrepository.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.zycus.sim.api.errors.InvalidParameterException;
import com.zycus.sim.api.errors.NoResourceFoundException;
import com.zycus.sim.api.errors.RequiredParametersMissing;
import com.zycus.sim.redisrepository.model.CachedSupplier;
import com.zycus.sim.redisrepository.service.RedisCacheReadServiceImpl;
import com.zycus.sim.redisrepository.service.RedisCacheWriteServiceImpl;

@RunWith(MockitoJUnitRunner.class)
public class CacheSupplierControllerTest {

	@Mock
	private RedisCacheWriteServiceImpl redisWriteCacheService;

	@Mock
	private RedisCacheReadServiceImpl redisReadCacheService;
	
	@InjectMocks
	private CacheSupplierController cacheSupplierController;

	@Mock
	private CachedSupplier cachedSupplier;
	@Mock
	List<String> list =new ArrayList<>();
	
	@Before
	public void setUp() throws Exception {
	}

	@Test(expected=RequiredParametersMissing.class)
	public void cacheSuppliersInRedisTmsTenantIdIsNull() {
		cacheSupplierController.cacheSuppliersInRedis(null, list, 1);
	}
	
	@Test(expected=RequiredParametersMissing.class)
	public void cacheSuppliersInRedisTmsTenantIdIsEmpty() {
		cacheSupplierController.cacheSuppliersInRedis("", list, 1);
	}

	@Test
	public void cacheSuppliersInRedisTmsTenantIdIsValid() {
		Mockito.when(redisWriteCacheService.loadSuppliersForTenantInRedis(Mockito.anyString(), Mockito.anyList())).thenReturn(3L);
		assertEquals("Successfully Loaded 3 Suppliers",cacheSupplierController.cacheSuppliersInRedis("123", list, 1));
		Mockito.verify(redisWriteCacheService).loadSuppliersForTenantInRedis(Mockito.anyString(), Mockito.anyList());
	}
	
	@Test(expected=NoResourceFoundException.class)
	public void cacheSuppliersInRedisTmsTenantIdIsValidAndSupplierIdsIsEmpty() {
		List<String> supplierIds = new ArrayList<>();
		cacheSupplierController.cacheSuppliersInRedis("123", supplierIds, 1);
		Mockito.verify(redisWriteCacheService).loadAllSuppliersForTenantInRedis(Mockito.anyString(), 1);
	}
	
	@Test(expected=NoResourceFoundException.class)
	public void cacheSuppliersInRedisTmsTenantIdIsValidAndSupplierIdsIsNull() {
		cacheSupplierController.cacheSuppliersInRedis("123", null, 1);
		Mockito.verify(redisWriteCacheService).loadAllSuppliersForTenantInRedis(Mockito.anyString(),1 );
	}
	
	
	
	@Test(expected=RequiredParametersMissing.class)
	public void findSupplierBySupplierIdTmsIdNull() {
		cacheSupplierController.findSupplierBySupplierId(null,"12");
	}
	@Test(expected=RequiredParametersMissing.class)
	public void findSupplierBySupplierIdTmsIdIsEmpty() {
		cacheSupplierController.findSupplierBySupplierId("","12");
	}
	
	@Test(expected=RequiredParametersMissing.class)
	public void findSupplierBySupplierIdSupplierIdNull() {
		cacheSupplierController.findSupplierBySupplierId("12",null);
	}
	@Test(expected=RequiredParametersMissing.class)
	public void findSupplierBySupplierIdSupplierIdIsEmpty() {
		cacheSupplierController.findSupplierBySupplierId("12","");
	}
	
	@Test
	public void findSupplierBySupplierIdValid() {		
		Optional<CachedSupplier> retValue = Optional.of(cachedSupplier);		
		Mockito.when(redisReadCacheService.findById(Mockito.anyString(), Mockito.anyString())).thenReturn(retValue);		
		Mockito.when(cachedSupplier.getData()).thenReturn("");
		assertEquals("",cacheSupplierController.findSupplierBySupplierId("123", "abc"));
	}
	
	@Test(expected=NoResourceFoundException.class)
	public void findSupplierBySupplierIdValidWithNodata() {		
		Optional<CachedSupplier> retValue = Optional.empty();		
		Mockito.when(redisReadCacheService.findById(Mockito.anyString(), Mockito.anyString())).thenReturn(retValue);
		cacheSupplierController.findSupplierBySupplierId("123", "abc");
		Mockito.verify(redisReadCacheService).findById(Mockito.anyString(), Mockito.anyString());	
	}
	
	@Test(expected=RequiredParametersMissing.class)
	public void findSuppliersByIdsTmsTenantIdNull(){
		cacheSupplierController.findSuppliersByIds(null, new ArrayList<>());		
	}
	
	@Test(expected=RequiredParametersMissing.class)
	public void findSuppliersByIdsTmsTenantIdIsEmpty(){
		cacheSupplierController.findSuppliersByIds("", new ArrayList<>());		
	}
	
	@Test(expected=RequiredParametersMissing.class)
	public void findSuppliersByIdsSupplierIdNull(){
		cacheSupplierController.findSuppliersByIds("12", null);		
	}
	
	@Test(expected=RequiredParametersMissing.class)
	public void findSuppliersByIdsSupplierIdEmpty(){
		cacheSupplierController.findSuppliersByIds("12", new ArrayList<>());		
	}
	
	@Test(expected=InvalidParameterException.class)
	public void findSuppliersByIdsSupplierIdSizeGreaterThanTen(){	
		Mockito.when(list.size()).thenReturn(11);		
		list.add("1235");
		cacheSupplierController.findSuppliersByIds("12",list);		
	}
	
	@Test(expected=NoResourceFoundException.class)
	public void findSuppliersByIdsSupplierValidRetValIsNull(){	
		List<String> supplierIds = new ArrayList<>();				
		Mockito.when(redisReadCacheService.findAllBySupplierIds(Mockito.anyString(), Mockito.any(List.class))).thenReturn(null);
		supplierIds.add("1235");
		assertNotNull(cacheSupplierController.findSuppliersByIds("12",supplierIds));	
		
	}
	
	@Test(expected=NoResourceFoundException.class)
	public void findSuppliersByIdsSupplierValidRetValIsEmpty(){	
		List<String> supplierIds = new ArrayList<>();
		Iterable<CachedSupplier> retval = new ArrayList<>();
		Mockito.when(redisReadCacheService.findAllBySupplierIds(Mockito.anyString(), Mockito.any(List.class))).thenReturn(retval);
		supplierIds.add("1235");
		assertNotNull(cacheSupplierController.findSuppliersByIds("12",supplierIds));	
		
	}
	
	
	@Test
	public void findSuppliersByIdsSupplierValidRetValIsNotEmpty(){	
		List<String> supplierIds = new ArrayList<>();
		List<CachedSupplier> list1 = new ArrayList<>();			
		list1.add(new CachedSupplier());
		Iterable<CachedSupplier> retval = list1;
		Mockito.when(redisReadCacheService.findAllBySupplierIds(Mockito.anyString(), Mockito.any(List.class))).thenReturn(retval);
		supplierIds.add("1235");
		assertNotNull(cacheSupplierController.findSuppliersByIds("12",supplierIds));	
		
	}
	
	@Test(expected=RequiredParametersMissing.class)
	public void findSuppliersByERPIdsTmsTenantIdNull(){
		cacheSupplierController.findSuppliersByERPIds(null, new ArrayList<>());		
	}
	
	@Test(expected=RequiredParametersMissing.class)
	public void findSuppliersByERPIdsTmsTenantIdIsEmpty(){
		cacheSupplierController.findSuppliersByERPIds("", new ArrayList<>());		
	}
	
	@Test(expected=RequiredParametersMissing.class)
	public void findSuppliersByERPIdsSupplierIdNull(){
		cacheSupplierController.findSuppliersByERPIds("12", null);		
	}
	
	@Test(expected=RequiredParametersMissing.class)
	public void findSuppliersByIdsSupplierERPIdEmpty(){
		cacheSupplierController.findSuppliersByERPIds("12", new ArrayList<>());		
	}
	
	@Test(expected=InvalidParameterException.class)
	public void findSuppliersByIdsSupplierERPIdSizeGreaterThanTen(){	
		Mockito.when(list.size()).thenReturn(11);		
		list.add("1235");
		cacheSupplierController.findSuppliersByERPIds("12",list);		
	}
	
	
	@Test(expected=NoResourceFoundException.class)
	public void findSuppliersByERPIdsSupplierValidRetValIsEmpty(){	
		List<String> supplierIds = new ArrayList<>();
		Iterable<CachedSupplier> list1 = new ArrayList<>();				
		Mockito.when(redisReadCacheService.findAllByERPIds(Mockito.anyString(), Mockito.any(List.class))).thenReturn(list1);
		supplierIds.add("1235");
		assertNotNull(cacheSupplierController.findSuppliersByERPIds("12",supplierIds));	
		
	}
	
	
	@Test(expected=NoResourceFoundException.class)
	public void findSuppliersByERPIdsSupplierValidRetValIsNull(){	
		List<String> supplierIds = new ArrayList<>();					
		Mockito.when(redisReadCacheService.findAllByERPIds(Mockito.anyString(), Mockito.any(List.class))).thenReturn(null);
		supplierIds.add("1235");
		assertNotNull(cacheSupplierController.findSuppliersByERPIds("12",supplierIds));	
		
	}
	
	
	@Test
	public void findSuppliersByERPIdsSupplierValidRetValIsNotEmpty(){	
		List<String> supplierIds = new ArrayList<>();
		supplierIds.add("1235");
		List<CachedSupplier> list1 = new ArrayList<>();			
		list1.add(new CachedSupplier());
		Iterable<CachedSupplier> retval = list1;
		Mockito.when(redisReadCacheService.findAllByERPIds(Mockito.anyString(), Mockito.any(List.class))).thenReturn(retval);
		
		assertNotNull(cacheSupplierController.findSuppliersByERPIds("12",supplierIds));	
		
	}
	
	@Test(expected=RequiredParametersMissing.class)
	public void findSupplierByDBAIdTmsIdNull() {
		cacheSupplierController.findSupplierByDBAId(null,"12");
	}
	@Test(expected=RequiredParametersMissing.class)
	public void findSupplierByDBAIdTmsIdIsEmpty() {
		cacheSupplierController.findSupplierByDBAId("","12");
	}
	
	@Test(expected=RequiredParametersMissing.class)
	public void findSupplierByDBAIdSupplierIdNull() {
		cacheSupplierController.findSupplierByDBAId("12",null);
	}
	@Test(expected=RequiredParametersMissing.class)
	public void findSupplierByDBAIdSupplierIdIsEmpty() {
		cacheSupplierController.findSupplierByDBAId("12","");
	}
	
	@Test
	public void findSupplierByDBAIdValid() {		
		Optional<CachedSupplier> retValue = Optional.of(cachedSupplier);		
		Mockito.when(redisReadCacheService.findByDBAId(Mockito.anyString(), Mockito.anyString())).thenReturn(retValue);		
		Mockito.when(cachedSupplier.getData()).thenReturn("");
		assertNotNull(cacheSupplierController.findSupplierByDBAId("123", "abc"));
	}
	@Test(expected=NoResourceFoundException.class)
	public void findSupplierByDBAIdValidIsEmpty() {		
		Optional<CachedSupplier> retValue = Optional.empty();		
		Mockito.when(redisReadCacheService.findByDBAId(Mockito.anyString(), Mockito.anyString())).thenReturn(retValue);		
		
		assertNotNull(cacheSupplierController.findSupplierByDBAId("123", "abc"));
	}
	
	@Test(expected=RequiredParametersMissing.class)
	public void findSuppliersByDBAIdsTmsTenantIdNull(){
		cacheSupplierController.findSuppliersByDBAIds(null, new ArrayList<>());		
	}
	
	@Test(expected=RequiredParametersMissing.class)
	public void findSuppliersByDBAIdsTmsTenantIdIsEmpty(){
		cacheSupplierController.findSuppliersByDBAIds("", new ArrayList<>());		
	}
	
	@Test(expected=RequiredParametersMissing.class)
	public void findSuppliersByDBAIdsSupplierIdNull(){
		cacheSupplierController.findSuppliersByDBAIds("12", null);		
	}
	
	@Test(expected=RequiredParametersMissing.class)
	public void findSuppliersByDBAIdsSupplierDBAIdsEmpty(){
		cacheSupplierController.findSuppliersByDBAIds("12", new ArrayList<>());		
	}
	
	@Test(expected=InvalidParameterException.class)
	public void findSuppliersByDBAIdsSupplierDBAIdsSizeGreaterThanTen(){	
		Mockito.when(list.size()).thenReturn(11);		
		list.add("1235");
		cacheSupplierController.findSuppliersByDBAIds("12",list);		
	}
	
	
	@Test(expected=NoResourceFoundException.class)
	public void findSuppliersByDBAIdsSupplierValidRetValIsEmpty(){	
		List<String> supplierIds = new ArrayList<>();
		Iterable<CachedSupplier> list1 = new ArrayList<>();				
		Mockito.when(redisReadCacheService.findAllByDBAIds(Mockito.anyString(), Mockito.any(List.class))).thenReturn(list1);
		supplierIds.add("1235");
		assertNotNull(cacheSupplierController.findSuppliersByDBAIds("12",supplierIds));	
		
	}
	
	
	@Test(expected=NoResourceFoundException.class)
	public void findSuppliersByDBAIdsSupplierValidRetValIsNull(){	
		List<String> supplierIds = new ArrayList<>();		
		Mockito.when(redisReadCacheService.findAllByDBAIds(Mockito.anyString(), Mockito.any(List.class))).thenReturn(null);
		supplierIds.add("1235");
		assertNotNull(cacheSupplierController.findSuppliersByDBAIds("12",supplierIds));	
		
	}
	
	
	@Test
	public void findSuppliersByDBAIdsSupplierValidRetValIsNotEmpty(){	
		List<String> supplierIds = new ArrayList<>();
		supplierIds.add("1235");
		List<CachedSupplier> list1 = new ArrayList<>();			
		list1.add(new CachedSupplier());
		Iterable<CachedSupplier> retval = list1;
		Mockito.when(redisReadCacheService.findAllByDBAIds(Mockito.anyString(), Mockito.any(List.class))).thenReturn(retval);
		
		assertNotNull(cacheSupplierController.findSuppliersByDBAIds("12",supplierIds));	
		
	}
	
	@Test(expected=RequiredParametersMissing.class)
	public void findSupplierByERPIdTmsIdNull() {
		cacheSupplierController.findSupplierByERPIds(null,"12");
	}
	@Test(expected=RequiredParametersMissing.class)
	public void findSupplierByERPIdTmsIdIsEmpty() {
		cacheSupplierController.findSupplierByERPIds("","12");
	}
	
	@Test(expected=RequiredParametersMissing.class)
	public void findSupplierByERPIdSupplierIdNull() {
		cacheSupplierController.findSupplierByERPIds("12",null);
	}
	@Test(expected=RequiredParametersMissing.class)
	public void findSupplierByERPIdSupplierIdIsEmpty() {
		cacheSupplierController.findSupplierByERPIds("12","");
	}
	
	@Test
	public void findSupplierByERPIdValid() {		
		Optional<CachedSupplier> retValue = Optional.of(cachedSupplier);		
		Mockito.when(redisReadCacheService.findByERPId(Mockito.anyString(), Mockito.anyString())).thenReturn(retValue);		
		Mockito.when(cachedSupplier.getData()).thenReturn("");
		assertNotNull(cacheSupplierController.findSupplierByERPIds("123", "abc"));
	}
	@Test(expected=NoResourceFoundException.class)
	public void findSupplierByERPIdValidIsEmpty() {		
		Optional<CachedSupplier> retValue = Optional.empty();		
		Mockito.when(redisReadCacheService.findByERPId(Mockito.anyString(), Mockito.anyString())).thenReturn(retValue);		
		
		assertNotNull(cacheSupplierController.findSupplierByERPIds("123", "abc"));
	}
	
	
}
