package com.zycus.sim.redisrepository.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import com.google.gson.Gson;
import com.zycus.sim.redisrepository.model.CachedDBA;
import com.zycus.sim.redisrepository.model.CachedSupplier;
import com.zycus.sim.redisrepository.model.ExtSupplier;
import com.zycus.sim.redisrepository.repository.CachedDBARepository;
import com.zycus.sim.redisrepository.repository.CachedSupplierRepository;
import com.zycus.sim.redisrepository.repository.ExtSupplierRepository;

import app.zycus.bp.simapi.bo.ContactDetails;
import app.zycus.bp.simapi.bo.SIMSupplierBo;
import app.zycus.bp.simapi.bo.SupplierProfile;

@RunWith(MockitoJUnitRunner.class)
public class RedisCacheReadServiceImplTest {
	@Mock
	CachedSupplierRepository cachedSupplierRepo;
	@Mock
	ExtSupplierRepository extSupplierRepo;
	@Mock
	CachedDBARepository cachedDbaRepo;
	
	
	@InjectMocks
	RedisCacheReadServiceImpl redisCacheReadServiceImpl;


	@Before
	public void setUp() throws Exception {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void findById() {
		Optional<CachedSupplier> optional= Optional.of(new CachedSupplier());
		Mockito.when(cachedSupplierRepo.findById(Mockito.anyString())).thenReturn(optional);
		redisCacheReadServiceImpl.findById("123", "123");
		Mockito.verify(cachedSupplierRepo).findById(Mockito.anyString());		
	}

	@Test
	public void findByERPId() {
		ExtSupplier extSupplier = new ExtSupplier();
		extSupplier.setZycusSupplierId("abc");
		Optional<ExtSupplier> optionalExt= Optional.of(extSupplier);
		Optional<CachedSupplier> optional= Optional.of(new CachedSupplier());
		Mockito.when(extSupplierRepo.findById(Mockito.anyString())).thenReturn(optionalExt);
		Mockito.when(cachedSupplierRepo.findById(Mockito.anyString())).thenReturn(optional);
		assertEquals(optional,redisCacheReadServiceImpl.findByERPId("123", "123"));
		Mockito.verify(cachedSupplierRepo).findById(Mockito.anyString());		
	}
	
	@Test
	public void findByERPIdNoDataInExtRepo() {
		ExtSupplier extSupplier = new ExtSupplier();
		extSupplier.setZycusSupplierId("abc");
		Optional<ExtSupplier> optionalExt= Optional.empty();		
		Mockito.when(extSupplierRepo.findById(Mockito.anyString())).thenReturn(optionalExt);		
		assertEquals(Optional.empty(),redisCacheReadServiceImpl.findByERPId("123", "123"));
		Mockito.verify(cachedSupplierRepo,Mockito.times(0)).findById(Mockito.anyString());		
	}
	
	@Test
	public void findByDBAId() {
		
		CachedDBA cachedDBA = new CachedDBA();
		cachedDBA.setZycusSupplierId("123");
		Optional<CachedDBA> optional= Optional.of(cachedDBA);
		Optional<CachedSupplier> optionalSupplier= Optional.of(new CachedSupplier());	
		Mockito.when(cachedDbaRepo.findById(Mockito.anyString())).thenReturn(optional);
		Mockito.when(cachedSupplierRepo.findById(Mockito.anyString())).thenReturn(optionalSupplier);
		assertEquals(optionalSupplier,redisCacheReadServiceImpl.findByDBAId("123", "123"));
		Mockito.verify(cachedSupplierRepo).findById(Mockito.anyString());		
	}
	
	@Test
	public void findByDBAIdNoDataInRepo() {
		
		Optional<CachedDBA> optional= Optional.empty();		
		Mockito.when(cachedDbaRepo.findById(Mockito.anyString())).thenReturn(optional);
		assertEquals(optional,redisCacheReadServiceImpl.findByDBAId("123", "123"));
		Mockito.verify(cachedSupplierRepo,Mockito.times(0)).findById(Mockito.anyString());		
	}
	
	@Test
	public void findAllSupplierIds(){
		List<String> supplierIds= new ArrayList<>();
		String tmsTenantId = "125";
		Iterable<CachedSupplier> cachedSupplier = new ArrayList<>(); 
		Mockito.when(cachedSupplierRepo.findAllById(Mockito.anyIterable())).thenReturn(cachedSupplier);
		Assert.assertNotNull(redisCacheReadServiceImpl.findAllBySupplierIds(tmsTenantId, supplierIds));
		
	}
	
	@Test
	public void findAllSupplierIdsSuuplierIdWithValue(){
		List<String> supplierIds= new ArrayList<>();
		supplierIds.add("2536");
		String tmsTenantId = "125";
		Iterable<CachedSupplier> cachedSupplier = new ArrayList<>(); 
		Mockito.when(cachedSupplierRepo.findAllById(Mockito.anyIterable())).thenReturn(cachedSupplier);
		Assert.assertNotNull(redisCacheReadServiceImpl.findAllBySupplierIds(tmsTenantId, supplierIds));
		
	}
	
	
	@Test
	public void findAllSupplierIdByERPIds(){
		List<String> erpIds= new ArrayList<>();
		erpIds.add("2536");
		String tmsTenantId = "125";
		List<CachedSupplier> list = new ArrayList<>(); 
		list.add(new CachedSupplier());
		Iterable<CachedSupplier> cachedSupplier=list;
		Set<ExtSupplier> ids = new HashSet<>();
		ids.add(new ExtSupplier());	
		Iterable<ExtSupplier> iterable = ids;
		Mockito.when(extSupplierRepo.findAllById(Mockito.anyIterable())).thenReturn(iterable);
		Mockito.when(cachedSupplierRepo.findAllById(Mockito.anyIterable())).thenReturn(cachedSupplier);
		Assert.assertEquals(1,((ArrayList<CachedSupplier>)redisCacheReadServiceImpl.findAllByERPIds(tmsTenantId, erpIds)).size());
		Mockito.verify(extSupplierRepo).findAllById(Mockito.anyIterable());
		Mockito.verify(cachedSupplierRepo).findAllById(Mockito.anyIterable());
	}
	
	
	@Test
	public void findAllSupplierIdByERPIdsWithExtSupNull(){
		List<String> erpIds= new ArrayList<>();
		erpIds.add("2536");
		String tmsTenantId = "125";		
		Mockito.when(extSupplierRepo.findAllById(Mockito.anyIterable())).thenReturn(null);		
		Assert.assertEquals(0,((ArrayList<CachedSupplier>)redisCacheReadServiceImpl.findAllByERPIds(tmsTenantId, erpIds)).size());
		Mockito.verify(extSupplierRepo).findAllById(Mockito.anyIterable());
		
	}
	
	@Test
	public void findAllSupplierIdByERPIdsWithExtSupIsEmpty(){
		List<String> erpIds= new ArrayList<>();
		String tmsTenantId = "125";				
		Assert.assertEquals(0,((ArrayList<CachedSupplier>)redisCacheReadServiceImpl.findAllByERPIds(tmsTenantId, erpIds)).size());
		Mockito.verify(extSupplierRepo,Mockito.times(0)).findAllById(Mockito.anyIterable());
		
	}
	
	@Test
	public void findAlByDBAIds()
	{
		List<String> dbaIds= new ArrayList<>();
		dbaIds.add("2536");
		String tmsTenantId = "125";
		List<CachedSupplier> list = new ArrayList<>(); 
		list.add(new CachedSupplier());
		Iterable<CachedSupplier> cachedSupplier=list;
		Set<CachedDBA> ids = new HashSet<>();
		ids.add(new CachedDBA());	
		Iterable<CachedDBA> iterable = ids;
		Mockito.when(cachedDbaRepo.findAllById(Mockito.anyIterable())).thenReturn(iterable);
		Mockito.when(cachedSupplierRepo.findAllById(Mockito.anyIterable())).thenReturn(cachedSupplier);
		Assert.assertEquals(1,((ArrayList<CachedSupplier>)redisCacheReadServiceImpl.findAllByDBAIds(tmsTenantId, dbaIds)).size());
		Mockito.verify(cachedDbaRepo).findAllById(Mockito.anyIterable());
		Mockito.verify(cachedSupplierRepo).findAllById(Mockito.anyIterable());		
	}	
	
	@Test
	public void findAlByDBAIdsDataFromRepoNull()
	{
		List<String> dbaIds= new ArrayList<>();
		dbaIds.add("2536");
		String tmsTenantId = "125";		
		Mockito.when(cachedDbaRepo.findAllById(Mockito.anyIterable())).thenReturn(null);		
		Assert.assertEquals(0,((ArrayList<CachedSupplier>)redisCacheReadServiceImpl.findAllByDBAIds(tmsTenantId, dbaIds)).size());
		Mockito.verify(cachedDbaRepo).findAllById(Mockito.anyIterable());
		Mockito.verify(cachedSupplierRepo,Mockito.times(0)).findAllById(Mockito.anyIterable());		
	}
	
	@Test
	public void findAllContactDetailsByDBAIdsAndEmailtmsTenantIdNull(){
		assertFalse(redisCacheReadServiceImpl.findAllContactsByDBAIdsAndEmail(null, "john@zycus.com", new ArrayList<String>()).iterator().hasNext());
		
	}
	
	@Test
	public void findAllContactDetailsByDBAIdsAndEmailDBIdIsEmpty(){
		assertFalse(redisCacheReadServiceImpl.findAllContactsByDBAIdsAndEmail("123", "john@zycus.com", new ArrayList<String>()).iterator().hasNext());
		
	}
	
	@Test
	public void findAllContactsByDBAIdsAndEmailWhenSupplierBoNull() {
		ArrayList<String> dBAIds = new ArrayList<String>();
		dBAIds.add("abc");
		List<String> dbaIds= new ArrayList<>();
		dbaIds.add("2536");
		String tmsTenantId = "125";
		List<CachedSupplier> list = new ArrayList<>(); 
		list.add(new CachedSupplier());
		Iterable<CachedSupplier> cachedSupplier=list;
		Set<CachedDBA> ids = new HashSet<>();
		ids.add(new CachedDBA());	
		Iterable<CachedDBA> iterable = ids;
		Mockito.when(cachedDbaRepo.findAllById(Mockito.anyIterable())).thenReturn(iterable);
		Mockito.when(cachedSupplierRepo.findAllById(Mockito.anyIterable())).thenReturn(cachedSupplier);
		assertFalse(redisCacheReadServiceImpl.findAllContactsByDBAIdsAndEmail(tmsTenantId, "john@zycus.com",dbaIds).iterator().hasNext());
		
	}
	
	@Test
	public void findAllContactsByDBAIdsAndEmailWhenSupplierProfileIsNull() {		
		SIMSupplierBo simSupplierBo = new SIMSupplierBo();
		simSupplierBo.setDbaId(1234L);		
		Gson gson = new Gson();		
		ArrayList<String> dBAIds = new ArrayList<String>();
		dBAIds.add("abc");
		List<String> dbaIds= new ArrayList<>();
		dbaIds.add("2536");
		String tmsTenantId = "125";
		List<CachedSupplier> list = new ArrayList<>(); 
		CachedSupplier cachedSupplierData= new CachedSupplier();
		cachedSupplierData.setData(gson.toJson(simSupplierBo));
		list.add(cachedSupplierData);
		Iterable<CachedSupplier> cachedSupplier=list;
		Set<CachedDBA> ids = new HashSet<>();
		ids.add(new CachedDBA());	
		Iterable<CachedDBA> iterable = ids;
		Mockito.when(cachedDbaRepo.findAllById(Mockito.anyIterable())).thenReturn(iterable);
		Mockito.when(cachedSupplierRepo.findAllById(Mockito.anyIterable())).thenReturn(cachedSupplier);
		assertFalse(redisCacheReadServiceImpl.findAllContactsByDBAIdsAndEmail(tmsTenantId, "john@zycus.com",dbaIds).iterator().hasNext());
		
	}
	
	@Test
	public void findAllContactsByDBAIdsAndEmailWhenSupContactDetailsIsNull() {		
		SIMSupplierBo simSupplierBo = new SIMSupplierBo();
		simSupplierBo.setDbaId(1234L);
		SupplierProfile supplierProfile = new SupplierProfile();
		simSupplierBo.setSupplierProfile(supplierProfile);		
		Gson gson = new Gson();		
		ArrayList<String> dBAIds = new ArrayList<String>();
		dBAIds.add("abc");
		List<String> dbaIds= new ArrayList<>();
		dbaIds.add("2536");
		String tmsTenantId = "125";
		List<CachedSupplier> list = new ArrayList<>(); 
		CachedSupplier cachedSupplierData= new CachedSupplier();
		cachedSupplierData.setData(gson.toJson(simSupplierBo));
		list.add(cachedSupplierData);
		Iterable<CachedSupplier> cachedSupplier=list;
		Set<CachedDBA> ids = new HashSet<>();
		ids.add(new CachedDBA());	
		Iterable<CachedDBA> iterable = ids;
		Mockito.when(cachedDbaRepo.findAllById(Mockito.anyIterable())).thenReturn(iterable);
		Mockito.when(cachedSupplierRepo.findAllById(Mockito.anyIterable())).thenReturn(cachedSupplier);
		assertFalse(redisCacheReadServiceImpl.findAllContactsByDBAIdsAndEmail(tmsTenantId, "john@zycus.com",dbaIds).iterator().hasNext());
		
	}
	
	@Test
	public void findAllContactsByDBAIdsAndEmailWhenSupContactDetailsIsEmpty() {
		
		SIMSupplierBo simSupplierBo = new SIMSupplierBo();
		simSupplierBo.setDbaId(1234L);
		SupplierProfile supplierProfile = new SupplierProfile();
		supplierProfile.setSupContactDetailsList(new ArrayList<>());
		simSupplierBo.setSupplierProfile(supplierProfile);		
		Gson gson = new Gson();		
		ArrayList<String> dBAIds = new ArrayList<String>();
		dBAIds.add("abc");
		List<String> dbaIds= new ArrayList<>();
		dbaIds.add("2536");
		String tmsTenantId = "125";
		List<CachedSupplier> list = new ArrayList<>(); 
		CachedSupplier cachedSupplierData= new CachedSupplier();
		cachedSupplierData.setData(gson.toJson(simSupplierBo));
		list.add(cachedSupplierData);
		Iterable<CachedSupplier> cachedSupplier=list;
		Set<CachedDBA> ids = new HashSet<>();
		ids.add(new CachedDBA());	
		Iterable<CachedDBA> iterable = ids;
		Mockito.when(cachedDbaRepo.findAllById(Mockito.anyIterable())).thenReturn(iterable);
		Mockito.when(cachedSupplierRepo.findAllById(Mockito.anyIterable())).thenReturn(cachedSupplier);
		assertFalse(redisCacheReadServiceImpl.findAllContactsByDBAIdsAndEmail(tmsTenantId, "john@zycus.com",dbaIds).iterator().hasNext());
	}
	
	@Test
	public void findAllContactsByDBAIdsAndEmailWhenSupContactDetailsValid() {		
		SIMSupplierBo simSupplierBo = new SIMSupplierBo();
		simSupplierBo.setDbaId(1234L);
		SupplierProfile supplierProfile = new SupplierProfile();
		ArrayList<ContactDetails> contactList = new ArrayList<>();
		ContactDetails contactDetails = new ContactDetails();
		contactDetails.setemail("john@zycus.com");
		contactList.add(contactDetails);
		supplierProfile.setSupContactDetailsList(contactList);
		simSupplierBo.setSupplierProfile(supplierProfile);
		Gson gson = new Gson();		
		ArrayList<String> dBAIds = new ArrayList<String>();
		dBAIds.add("abc");
		List<String> dbaIds= new ArrayList<>();
		dbaIds.add("2536");
		String tmsTenantId = "125";
		List<CachedSupplier> list = new ArrayList<>(); 
		CachedSupplier cachedSupplierData= new CachedSupplier();
		cachedSupplierData.setData(gson.toJson(simSupplierBo));
		list.add(cachedSupplierData);
		Iterable<CachedSupplier> cachedSupplier=list;
		Set<CachedDBA> ids = new HashSet<>();
		ids.add(new CachedDBA());	
		Iterable<CachedDBA> iterable = ids;
		Mockito.when(cachedDbaRepo.findAllById(Mockito.anyIterable())).thenReturn(iterable);
		Mockito.when(cachedSupplierRepo.findAllById(Mockito.anyIterable())).thenReturn(cachedSupplier);
		assertTrue(redisCacheReadServiceImpl.findAllContactsByDBAIdsAndEmail(tmsTenantId, "john@zycus.com",dbaIds).iterator().hasNext());
	}
	
	@Test
	public void findAllContactsByDBAIdsAndEmailWhenSupContactDetailsInValid() {		
		SIMSupplierBo simSupplierBo = new SIMSupplierBo();
		simSupplierBo.setDbaId(1234L);
		SupplierProfile supplierProfile = new SupplierProfile();
		ArrayList<ContactDetails> contactList = new ArrayList<>();
		ContactDetails contactDetails = new ContactDetails();
		contactDetails.setemail("dave@zycus.com");
		contactList.add(contactDetails);
		supplierProfile.setSupContactDetailsList(contactList);
		simSupplierBo.setSupplierProfile(supplierProfile);
		Gson gson = new Gson();		
		ArrayList<String> dBAIds = new ArrayList<String>();
		dBAIds.add("abc");
		List<String> dbaIds= new ArrayList<>();
		dbaIds.add("2536");
		String tmsTenantId = "125";
		List<CachedSupplier> list = new ArrayList<>(); 
		CachedSupplier cachedSupplierData= new CachedSupplier();
		cachedSupplierData.setData(gson.toJson(simSupplierBo));
		list.add(cachedSupplierData);
		Iterable<CachedSupplier> cachedSupplier=list;
		Set<CachedDBA> ids = new HashSet<>();
		ids.add(new CachedDBA());	
		Iterable<CachedDBA> iterable = ids;
		Mockito.when(cachedDbaRepo.findAllById(Mockito.anyIterable())).thenReturn(iterable);
		Mockito.when(cachedSupplierRepo.findAllById(Mockito.anyIterable())).thenReturn(cachedSupplier);
		assertFalse(redisCacheReadServiceImpl.findAllContactsByDBAIdsAndEmail(tmsTenantId, "john@zycus.com",dbaIds).iterator().hasNext());
	}
	
}
