package com.zycus.sim.redisrepository.service;

import app.zycus.bp.bo.QueryResult;
import app.zycus.bp.bo.SIMPlant;
import app.zycus.bp.simapi.bo.SIMSupplierBo;
import com.google.gson.Gson;
import com.zycus.sim.api.errors.DataFetchException;
import com.zycus.sim.api.errors.DependentServiceUnavailable;
import com.zycus.sim.api.errors.InvalidParameterException;
import com.zycus.sim.redisrepository.discovery.DiscoveryUtil;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RunWith(MockitoJUnitRunner.class)
public class RedisCacheWriteServiceImplTest {

    @Mock
    DiscoveryClient discoveryClient;

    @Mock
    RestTemplate restTemplate;

    @Mock
    RedisCacheServiceHelper helper;

    @InjectMocks
    RedisCacheWriteServiceImpl redisCacheWriteServiceImpl;

    @Mock
    DiscoveryUtil discoveryUtil;


    Optional<URI> uri;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
    }

    @Test()
    public void testLoadAllSuppliersForTenantInRedis() throws URISyntaxException {
        uri = Optional.of(new URI("/path"));
        SIMSupplierBo simSupplierBo = new SIMSupplierBo();
        List<SIMSupplierBo> simSupplierBos = new ArrayList<>();
        simSupplierBos.add(simSupplierBo);
        QueryResult<List<SIMSupplierBo>> queryResult = new QueryResult<>();
        queryResult.setResults(simSupplierBos);
        Gson gson = new Gson();
        ResponseEntity<String> response = ResponseEntity.ok(gson.toJson(queryResult));
        ResponseEntity<String> response1 = ResponseEntity.ok(null);
		Mockito.when(discoveryUtil.serviceUrl(discoveryClient, "sim", "123")).thenReturn(uri);
        Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(HttpEntity.class), (Class<String>) Mockito.any())).thenReturn(response, response1);
        redisCacheWriteServiceImpl.loadAllSuppliersForTenantInRedis("123", 0);
        Mockito.verify(helper, Mockito.times(1)).postToJMSForSolrUpdate(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(List.class));
        Mockito.verify(helper, Mockito.times(1)).saveSuppliers(Mockito.anyString(), Mockito.any(List.class));
        Mockito.verify(helper, Mockito.times(1)).saveExtSuppliers(Mockito.anyString(), Mockito.any(List.class));
        Mockito.verify(helper, Mockito.times(1)).saveDBAs(Mockito.anyString(), Mockito.any(List.class));

    }

    @Test(expected = DependentServiceUnavailable.class)
    public void testLoadAllSuppliersForTenantInRedisExceptionThrown() throws URISyntaxException {
        uri = Optional.of(new URI("/path"));
        SIMSupplierBo simSupplierBo = new SIMSupplierBo();
        List<SIMSupplierBo> simSupplierBos = new ArrayList<>();
        simSupplierBos.add(simSupplierBo);
        QueryResult<List<SIMSupplierBo>> queryResult = new QueryResult<>();
        queryResult.setResults(simSupplierBos);
        Gson gson = new Gson();
        ResponseEntity<String> response = ResponseEntity.ok(gson.toJson(queryResult));
        ResponseEntity<String> response1 = ResponseEntity.ok(null);
		Mockito.when(discoveryUtil.serviceUrl(discoveryClient, "sim", "123")).thenReturn(uri);
        Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(HttpEntity.class), (Class<String>) Mockito.any())).thenThrow(RestClientResponseException.class);
        redisCacheWriteServiceImpl.loadAllSuppliersForTenantInRedis("123", 1);
    }

    @Test(expected = DependentServiceUnavailable.class)
    public void testLoadAllSuppliersForTenantInRedisUriNotPresent() throws URISyntaxException {
        uri = Optional.empty();
        SIMSupplierBo simSupplierBo = new SIMSupplierBo();
        List<SIMSupplierBo> simSupplierBos = new ArrayList<>();
        simSupplierBos.add(simSupplierBo);
        QueryResult<List<SIMSupplierBo>> queryResult = new QueryResult<>();
        queryResult.setResults(simSupplierBos);
        Gson gson = new Gson();
        ResponseEntity<String> response = ResponseEntity.ok(gson.toJson(queryResult));
        ResponseEntity<String> response1 = ResponseEntity.ok(null);
		Mockito.when(discoveryUtil.serviceUrl(discoveryClient, "sim", "123")).thenReturn(uri);
        redisCacheWriteServiceImpl.loadAllSuppliersForTenantInRedis("123", 1);
    }


    @Test()
    public void testLoadAllSuppliersForTenantInRedisSupplierBoNull() throws URISyntaxException {
        uri = Optional.of(new URI("/path"));
        SIMSupplierBo simSupplierBo = new SIMSupplierBo();
        List<SIMSupplierBo> simSupplierBos = null;

        QueryResult<List<SIMSupplierBo>> queryResult = new QueryResult<>();
        queryResult.setResults(simSupplierBos);
        Gson gson = new Gson();
        ResponseEntity<String> response = ResponseEntity.ok(gson.toJson(queryResult));
        ResponseEntity<String> response1 = ResponseEntity.ok(null);
		Mockito.when(discoveryUtil.serviceUrl(discoveryClient, "sim", "123")).thenReturn(uri);
        Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(HttpEntity.class), (Class<String>) Mockito.any())).thenReturn(response, response1);
        redisCacheWriteServiceImpl.loadAllSuppliersForTenantInRedis("123", 1);
        Mockito.verify(helper, Mockito.times(0)).postToJMSForSolrUpdate(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(List.class));
        Mockito.verify(helper, Mockito.times(0)).saveSuppliers(Mockito.anyString(), Mockito.any(List.class));
        Mockito.verify(helper, Mockito.times(0)).saveExtSuppliers(Mockito.anyString(), Mockito.any(List.class));
        Mockito.verify(helper, Mockito.times(0)).saveDBAs(Mockito.anyString(), Mockito.any(List.class));

    }


    @Test()
    public void testLoadAllSuppliersForTenantInRedisNullData() throws URISyntaxException {
        uri = Optional.of(new URI("/path"));
        ResponseEntity<String> response1 = ResponseEntity.ok(null);
		Mockito.when(discoveryUtil.serviceUrl(discoveryClient, "sim", "123")).thenReturn(uri);
        Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(HttpEntity.class), (Class<String>) Mockito.any())).thenReturn(response1);
        redisCacheWriteServiceImpl.loadAllSuppliersForTenantInRedis("123", 1);
        Mockito.verify(helper, Mockito.times(0)).postToJMSForSolrUpdate(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(List.class));
        Mockito.verify(helper, Mockito.times(0)).saveSuppliers(Mockito.anyString(), Mockito.any(List.class));
        Mockito.verify(helper, Mockito.times(0)).saveExtSuppliers(Mockito.anyString(), Mockito.any(List.class));
        Mockito.verify(helper, Mockito.times(0)).saveDBAs(Mockito.anyString(), Mockito.any(List.class));
    }

    @Test(expected = RuntimeException.class)
    public void testLoadAllSuppliersForTenantInRedisException() throws URISyntaxException {
        uri = Optional.of(new URI("/path"));
        ResponseEntity<String> response1 = ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        Mockito.when(discoveryUtil.serviceUrl(discoveryClient, "sim", "123")).thenReturn(uri);
        Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(HttpEntity.class), (Class<String>) Mockito.any())).thenReturn(response1);
        redisCacheWriteServiceImpl.loadAllSuppliersForTenantInRedis("123", 1);
        Mockito.verify(helper, Mockito.times(0)).postToJMSForSolrUpdate(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(List.class));
        Mockito.verify(helper, Mockito.times(0)).saveSuppliers(Mockito.anyString(), Mockito.any(List.class));
        Mockito.verify(helper, Mockito.times(0)).saveExtSuppliers(Mockito.anyString(), Mockito.any(List.class));
        Mockito.verify(helper, Mockito.times(0)).saveDBAs(Mockito.anyString(), Mockito.any(List.class));
    }

    @Test
    public void testLoadSuppliersForTenantInRedis() throws URISyntaxException {
        uri = Optional.of(new URI("/path"));
        SIMSupplierBo simSupplierBo = new SIMSupplierBo();
        List<SIMSupplierBo> simSupplierBos = new ArrayList<>();
        simSupplierBos.add(simSupplierBo);
        QueryResult<List<SIMSupplierBo>> queryResult = new QueryResult<>();
        queryResult.setResults(simSupplierBos);
        Gson gson = new Gson();
        ResponseEntity<String> response = ResponseEntity.ok(gson.toJson(queryResult));
        ResponseEntity<String> response1 = ResponseEntity.ok(null);
		Mockito.when(discoveryUtil.serviceUrl(discoveryClient, "sim", "123")).thenReturn(uri);
        Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(HttpEntity.class), (Class<String>) Mockito.any())).thenReturn(response, response1);
        redisCacheWriteServiceImpl.loadSuppliersForTenantInRedis("123", new ArrayList<>());
        Mockito.verify(helper, Mockito.times(1)).postToJMSForSolrUpdate(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(List.class));
        Mockito.verify(helper, Mockito.times(1)).saveSuppliers(Mockito.anyString(), Mockito.any(List.class));
        Mockito.verify(helper, Mockito.times(1)).saveExtSuppliers(Mockito.anyString(), Mockito.any(List.class));
        Mockito.verify(helper, Mockito.times(1)).saveDBAs(Mockito.anyString(), Mockito.any(List.class));
    }

    @Test(expected = RuntimeException.class)
    public void testLoadSuppliersForTenantInRedisException() throws URISyntaxException {
        uri = Optional.of(new URI("/path"));
        SIMSupplierBo simSupplierBo = new SIMSupplierBo();
        List<SIMSupplierBo> simSupplierBos = new ArrayList<>();
        simSupplierBos.add(simSupplierBo);
        QueryResult<List<SIMSupplierBo>> queryResult = new QueryResult<>();
        queryResult.setResults(simSupplierBos);
        Gson gson = new Gson();
        ResponseEntity<String> response1 = ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();

        Mockito.when(discoveryUtil.serviceUrl(discoveryClient, "sim", "123")).thenReturn(uri);
        Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(HttpEntity.class), (Class<String>) Mockito.any())).thenReturn(response1);
        redisCacheWriteServiceImpl.loadSuppliersForTenantInRedis("123", new ArrayList<>());
    }

    @Test(expected = RuntimeException.class)
    public void testLoadSuppliersForTenantInRedisUriNull() throws URISyntaxException {
        uri = Optional.empty();
        SIMSupplierBo simSupplierBo = new SIMSupplierBo();
        List<SIMSupplierBo> simSupplierBos = new ArrayList<>();
        simSupplierBos.add(simSupplierBo);
        QueryResult<List<SIMSupplierBo>> queryResult = new QueryResult<>();
        queryResult.setResults(simSupplierBos);
        Gson gson = new Gson();
        ResponseEntity<String> response1 = ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();

        Mockito.when(discoveryUtil.serviceUrl(discoveryClient, "sim", "123")).thenReturn(uri);
        redisCacheWriteServiceImpl.loadSuppliersForTenantInRedis("123", new ArrayList<>());

    }


    @Test(expected = DependentServiceUnavailable.class)
    public void testLoadSuppliersForTenantInRedisExceptionThrown() throws URISyntaxException {
        uri = Optional.of(new URI("/path"));
        SIMSupplierBo simSupplierBo = new SIMSupplierBo();
        List<SIMSupplierBo> simSupplierBos = new ArrayList<>();
        simSupplierBos.add(simSupplierBo);
        QueryResult<List<SIMSupplierBo>> queryResult = new QueryResult<>();
        queryResult.setResults(simSupplierBos);
        Gson gson = new Gson();
        ResponseEntity<String> response1 = ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();

        Mockito.when(discoveryUtil.serviceUrl(discoveryClient, "sim", "123")).thenReturn(uri);
        Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(HttpEntity.class), (Class<String>) Mockito.any())).thenThrow(RestClientResponseException.class);
        redisCacheWriteServiceImpl.loadSuppliersForTenantInRedis("123", new ArrayList<>());
    }

    @Test
    public void testSyncAllSuppliersForTenantWithSolr() {
        List<SIMSupplierBo> lst = new ArrayList<>();
        SIMSupplierBo bo = new SIMSupplierBo();
        List<SIMPlant> lstp = new ArrayList<>();
        lstp.add(new SIMPlant());
        bo.setSupPlantList(lstp);
        lst.add(new SIMSupplierBo());
        Mockito.when(helper.getSuppliersForTenant("123")).thenReturn(lst);
        redisCacheWriteServiceImpl.syncAllSuppliersForTenantWithSolr("123");
        Mockito.verify(helper, Mockito.times(1)).postToJMSForSolrUpdate(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(List.class));
    }

    @Test
    public void testSyncSuppliersForTenantWithSolr() {
        List<SIMSupplierBo> lst = new ArrayList<>();
        SIMSupplierBo bo = new SIMSupplierBo();
        List<SIMPlant> lstp = new ArrayList<>();
        lstp.add(new SIMPlant());
        bo.setSupPlantList(lstp);
        lst.add(new SIMSupplierBo());
     //   Mockito.when(helper.getSuppliersForTenant("123")).thenReturn(lst);
        List<String> slist = new ArrayList<>();
        slist.add("SUP1");
        redisCacheWriteServiceImpl.syncSuppliersForTenantWithSolr("123",slist);
        Mockito.verify(helper, Mockito.times(1)).postToJMSForSolrUpdate(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.any(List.class));
    }
    
    @Test(expected = DataFetchException.class)
    public void testLoadSuppliersForTenantInRedisHttpStatusOtherThan200() throws URISyntaxException {
        uri = Optional.of(new URI("/path"));
        SIMSupplierBo simSupplierBo = new SIMSupplierBo();
        List<SIMSupplierBo> simSupplierBos = new ArrayList<>();
        simSupplierBos.add(simSupplierBo);
        QueryResult<List<SIMSupplierBo>> queryResult = new QueryResult<>();
        queryResult.setResults(simSupplierBos);
        Gson gson = new Gson();
        ResponseEntity<String> response1 = ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();

        Mockito.when(discoveryUtil.serviceUrl(discoveryClient, "sim", "123")).thenReturn(uri);
        Mockito.when(restTemplate.exchange(Mockito.anyString(), Mockito.any(), Mockito.any(HttpEntity.class), (Class<String>) Mockito.any())).thenReturn(new ResponseEntity<>(HttpStatus.BAD_REQUEST));
        redisCacheWriteServiceImpl.loadSuppliersForTenantInRedis("123", new ArrayList<>());
    }
}
