#!/bin/bash
set -e

if [[ $# != 2 ]]; then
  echo "Usage: $0 <stack_id> <environment>"
  exit 1
fi


export brewer_ip_port=10.70.1.214:5010
stack_id=$1
env=$2

curl --fail -X GET  "http://$brewer_ip_port/range?env=$env&stack_id=$stack_id" > range.json
current=$(jq -r .current range.json)
#curl --fail -X POST "http://$brewer_ip_port/range?env=$env&stack_id=$stack_id&last=$current"

export ANSIBLE_STDOUT_CALLBACK=debug
status=0
ansible-playbook -i 127.0.0.1, --connection=local ../terraform_files/deployment-scripts/launch_vms.yaml -e "platform=vmware env=$env package_deploy_run_path=`pwd` stack_id=$stack_id current=$current" || status=$?

if [[ $status == 0 ]]
then    # success
  echo "Deployment on $current successful"
  curl --fail -X POST "http://$brewer_ip_port/range?env=$env&stack_id=$stack_id&last=$current"
else    # failure
  echo "Deployment on $current failed"
fi

exit $status
