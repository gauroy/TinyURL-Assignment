pwd
../terraform_files/deployment-scripts/launch_vms.sh $1 $2
deployment_status=$?         # call first time
if [[ $deployment_status != 0 ]]
then
  echo "First deployment failed. Trying again..."
../terraform_files/deployment-scripts/launch_vms.sh $1 $2     # this time API will automatically provide different color to deploy on
fi
